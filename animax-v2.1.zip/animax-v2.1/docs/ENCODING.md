# Encoding

## Default profile

| Setting | Default | Effect |
|---|---:|---|
| `OUTPUT_HEIGHT` | `1080` | 1920×1080 black canvas; asks for up to 1080p source |
| `VIDEO_PRESET` | `veryfast` | x264 compression/speed trade-off |
| `VIDEO_CRF` | `21` | Lower numbers request higher quality and usually larger files |
| `TARGET_SIZE_MB` | `400` | Duration-based VBV bitrate ceiling with mux/audio headroom |
| `MAX_OUTPUT_MB` | `500` | Final per-video size ceiling |
| `ENCODE_THREADS` | `2` | Decoder and encoder thread limits |
| `UPLOAD_LIMIT_MB` | `1000` | Discord attachment cap; the lower of this and MAX_OUTPUT_MB wins |
| `AUTO_COMPRESS` | `true` | Allow a bounded extra encode if the result exceeds the final cap |

Frame rate is fixed at 24/1. Audio is AAC at 128 kb/s. Output uses H.264 High profile and yuv420p for broad Discord/mobile playback support. HEVC and AV1 can compress better but software encoding costs more CPU and playback support differs across Discord clients.

`QUALITY` and `ENCODER_PRESET` from V2 no longer select the profile. Your `.env` is not overwritten during upgrade; use the new keys above to customize it. `SUBTITLE_FALLBACK` and `PREPARE_TIMEOUT` are also obsolete.

## Size and quality

For a 24-minute episode, a 400 MB budget allows about 2 Mb/s of video after reserving audio and muxing headroom. CRF lets uncomplicated scenes use fewer bits; the bitrate ceiling restrains complex scenes. It does not pad a small file to 300 MB. A normal episode may land below 300 MB or approach the target. Long episodes and grainy/action-heavy sources can lose visible detail at this budget.

There is no way to guarantee both a fixed small file and unchanged quality for arbitrary material. Increase `TARGET_SIZE_MB` toward 450 and `MAX_OUTPUT_MB` to 500 if a difficult source needs more bits. Increase both for a feature-length episode. `VIDEO_CRF=20` asks for higher quality when the bitrate ceiling permits it. Do not expect upscaling to restore missing source detail.

The output-size check happens before upload. If a rare result exceeds the final cap, `AUTO_COMPRESS=true` permits additional whole-video recompression; otherwise the episode stops with a size error. The program never truncates or splits it.

## CPU and memory

The normal path uses one encode. The filter chain drops/converts frames to 24 fps, scales the complete source picture, burns captions into that picture, and adds black padding. Rendering before padding avoids processing black side areas in the subtitle filter. Scaling uses fast bilinear interpolation; it favors speed over sharper, more expensive scaling kernels.

Chromium captures the URL, headers, cookies and one English caption file, then closes before yt-dlp downloads the episode. It stays closed during encoding and uploading. Downloads and uploads use files on disk rather than loading a whole episode into Python memory.

x264 uses two reference frames, three B-frames, ten look-ahead frames and no synchronous look-ahead queue. The decoder and encoder default to two threads; the filter pipeline uses one. These reduce parallel resource use, but are not an OS-level total RAM or CPU quota. More than two OS threads can still exist, and browser resolution has a separate memory peak.

On a small/shared VPS try `ENCODE_THREADS=1`. Encoding will usually take longer. On a larger VPS, 3 or 4 threads may reduce elapsed time but use more CPU and memory. A CPU-only machine cannot make burn-in free: 1080p must be decoded, filtered and re-encoded. Moving from V2's ultrafast preset to veryfast improves compression but can take longer per frame even with these pipeline savings. No server-specific speedup or peak-memory number is promised.

## Padding

4:3 video fills a 1440×1080 picture area inside a 1920×1080 canvas, with 240-pixel black bars on each side. Non-square source pixels and rotation are accounted for. Wide cinema material receives top/bottom bars. Scaling uses even-pixel rounding, without a crop filter or stretch-to-fill operation.

A lower-resolution source is scaled to the requested canvas, but remains limited by its original detail. Pixels cropped upstream cannot be recovered. If a provider has already encoded black borders into the image, this program does not detect and crop them away.

## Captions

For dub, English tracks labeled dub/CC/closed captions are preferred over generic English tracks; signs/song-only tracks rank lower. When the source only offers a translation, the text can differ from the spoken dub. Track selection cannot create missing dub-matched captions. A missing English track is reported instead of invented.

The provider's WebVTT bytes are kept unchanged. FFmpeg/libass renders their cue wording, line breaks and timestamps; no paraphrasing, translation or timing offset is applied. Converting 23.976 fps to 24 fps preserves elapsed time rather than speeding up audio, avoiding a cumulative subtitle timing shift.

The font is Liberation Sans, an open Arial-compatible substitute, with smaller text and opaque black boxes. The style approximates the supplied screenshot. The exact player font cannot be identified from a screenshot alone, and the API caption text does not necessarily carry the player's CSS. FFmpeg/libass does not reproduce all browser WebVTT CSS/positioning features, so pixel-identical browser rendering is not guaranteed.

Dub always burns available English captions. `SUBTITLE_MODE=burn` does the same for sub/fallback videos. Advanced `mux` or `none` affect only sub videos. Burn failure remains an error, not a silent change to soft subtitles.

V2 output caches do not meet this profile and are not reused. Previously uploaded episodes still count as completed until you deliberately use force or confirm `.reset`.
