# Operating ANIMAX

## Reset

`.reset` creates a confirmation request; it does not delete anything yet. It replies with a command such as `.reset confirm a13c9f`. Enter the displayed command in the same channel within 60 seconds, or use `.reset cancel`.

Confirmation clears all accounts/destinations in this installation's:

- `anime.json`, its backup/temp files, and saved jobs within it;
- legacy `state.json` and its backup/temp files;
- `downloads/`, including completed and partial video caches, cookies and ready markers.

It does not delete `.env`, title overrides, existing Discord messages, log files, rate-limit cooldowns, release backups or migration backups. Old backup directories are not imported automatically. Diagnostic logs may still contain historical message IDs. After reset, search/history are empty and `.download 21 dub 1 100` downloads and uploads episode 1 again. Existing Discord videos are not used to reconstruct history.

Reset is refused while an episode job is running. Use `.cancel` and wait for it to finish first. Starting a job invalidates an unconfirmed reset. The confirmation code is one-use, account/channel-bound and held in memory, so a restart expires it.

File moves and the new empty journal form a recoverable transaction. If the process stops before commit, startup restores the staged history/cache. After commit, interrupted cache deletion is retried at startup without restoring completed history. A reset has no interactive undo. Do not restore old history unless you intend to restore its duplicate-skip behavior.

## Commands

`.download MAL_ID dub|sub START END [resume|force]` uses inclusive bounds. Default resume mode skips recorded uploads; force deliberately permits duplicates. `.resume` (alias `.retry`) runs the latest saved job. `.status` reports the current/last job, `.cancel` requests cancellation, and `.history MAL_ID` summarizes local records.

`.search QUERY` searches the current account's recorded uploaded messages and returns at most five fuzzy matches. It recognizes common episode-marker typos and reordered title words. It does not search the provider catalog or verify that historical Discord messages still exist. The displayed links are message permalinks, not signed attachment links.

`.getlist` uploads only the current `anime.json` file. It contains account/channel/message metadata; share carefully. `.help` lists canonical commands, and `.help <name>` gives syntax. Only commands authored by the logged-in account are processed.

## Progress and uploads

An episode has one automatic status message in the command channel. Downloading shows a reported byte/fragment percentage. Encoding shows `Enhancing | 0:1` with elapsed minutes:seconds. Uploading uses an indeterminate value because the SDK does not expose a reliable byte percentage. Successful uploads show 100% only after a returned message ID is journaled.

`STATUS_INTERVAL=8` means the elapsed display updates about every eight seconds, not every second. It will therefore skip some timer values. Lowering this to the supported minimum of five seconds sends more Discord edits. The timer is not an ETA.

With nonzero `CHANNEL_ID`, automatic statuses remain. Otherwise a confirmed upload's status is deleted after the accepted ID is saved. Failed/cancelled/uncertain statuses stay. The accepted `.download` command trigger is still deleted unless `DELETE_DOWNLOAD_TRIGGER=false`.

New video captions contain only the title/episode and any fallback/missing-caption note. There is no CDN hyperlink or post-send caption edit. Existing messages are not edited retroactively. Videos reply to the nearest earlier episode message in the same anime/account/destination, with no mention notification.

## Retry safety

Dub-to-sub fallback requires positive missing-source evidence. Timeouts, transport errors, caption failures, rate limits and upload errors do not change language. A fallback is labeled and recorded as actual sub while satisfying the requested dub episode for future resume.

CDN 429 responses stop further download requests, honor Retry-After, save cooldowns and slow request pacing. Reset does not remove cooldowns. Do not run parallel downloaders or delete cooldown files to evade a limit.

Discord cloud attachments remain the preferred upload route. Account limits and permissions still apply. A final-send timeout or cancellation may mean Discord accepted the message without returning confirmation. The program marks that case for review rather than automatically resending. Check the destination before force or reset; both can deliberately create duplicates. No local journal can guarantee exactly-once delivery across every crash window.

## Services and diagnostics

```bash
python3 manage.py service status
sudo python3 manage.py service restart
sudo python3 manage.py service logs
python3 manage.py service status-detached
python3 manage.py service stop-detached
.venv/bin/python manage.py doctor
.venv/bin/python manage.py doctor --source 21 dub 1
```

The source doctor checks browser/manifest access, not a complete upload. Do not repeatedly probe while rate-limited. Existing systemd units still invoke the root `bot.py`, so an in-place update does not require moving the service.

```bash
tail -n 80 logs/bot.log
cat logs/upload-21-dub-1.json
```

Upload JSON reports record stages, HTTP/code failures, accepted IDs and uncertain outcomes. Episode process logs contain exit codes and elapsed time. Detailed media logs may contain signed URLs; redact before sharing.

Other retained settings include `UPLOAD_TIMEOUT=1800`, `OPERATION_TIMEOUT=3600`, `RESOLVE_TIMEOUT=60`, `REQUEST_INTERVAL=0.25`, `RATE_LIMIT_COOLDOWN=300`, `RATE_LIMIT_RETRIES=2`, `EPISODE_ATTEMPTS=3`, `MAX_CONSECUTIVE_FAILURES=3`, `UPLOAD_DELAY=2`, `AUTO_RESUME=true`, `KEEP_DOWNLOADS=false`, `MAX_TEMP_GIB=8`, `MAX_EPISODES=1000`, and `HEADLESS=true`. Restart after changing `.env`.

Successful workspaces are removed by default. Failed work remains for recovery and can consume disk. The per-episode disk guard is not a global cache quota.
