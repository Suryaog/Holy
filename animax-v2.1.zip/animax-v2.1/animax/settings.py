from __future__ import annotations

import math
import os
from dataclasses import dataclass


def number(name, default, low, high, kind=int):
    value = kind(os.getenv(name, str(default)))
    if not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f"{name} must be between {low} and {high}.")
    return value


def enabled(name, default=True):
    return os.getenv(name, str(default)).lower() not in {"0", "false", "no", "off"}


@dataclass
class Settings:
    channel_id: int = 0
    upload_mb: int = 1000
    quality: int = 1080
    subtitle_mode: str = "burn"
    max_episodes: int = 1000
    max_temp_bytes: int = 8 * 1024**3
    operation_timeout: int = 3600
    resolve_timeout: int = 60
    delay: int = 2
    attempts: int = 3
    max_consecutive_failures: int = 3
    headless: bool = True
    request_interval: float = 0.25
    rate_limit_cooldown: int = 300
    rate_limit_retries: int = 2
    status_interval: int = 8
    auto_resume: bool = True
    auto_compress: bool = True
    subtitle_fallback: bool = (
        False  # Legacy setting retained for upgrade compatibility; no soft fallback.
    )
    keep_downloads: bool = False
    upload_timeout: int = 1800
    upload_mode: str = "auto"
    prepare_timeout: int = 300
    delete_trigger: bool = True
    encoder_preset: str = "veryfast"
    encode_threads: int = 2
    target_mb: int = 400
    output_max_mb: int = 500
    video_crf: int = 21
    dub_fallback: bool = True

    @classmethod
    def from_env(cls):
        mode = os.getenv("SUBTITLE_MODE", "burn").lower()
        if mode not in {"burn", "mux", "none"}:
            raise ValueError("SUBTITLE_MODE must be burn, mux or none.")
        upload_mode = os.getenv("UPLOAD_MODE", "auto").lower()
        if upload_mode not in {"auto", "cloud", "multipart"}:
            raise ValueError("UPLOAD_MODE must be auto, cloud or multipart.")
        preset = os.getenv("VIDEO_PRESET", "veryfast").lower()
        if preset not in {
            "ultrafast",
            "superfast",
            "veryfast",
            "faster",
            "fast",
            "medium",
            "slow",
        }:
            raise ValueError(
                "VIDEO_PRESET must be ultrafast, superfast, veryfast, faster, fast, medium or slow."
            )
        return cls(
            encode_threads=number("ENCODE_THREADS", 2, 1, 16),
            target_mb=number("TARGET_SIZE_MB", 400, 50, 2000),
            output_max_mb=number("MAX_OUTPUT_MB", 500, 50, 2000),
            video_crf=number("VIDEO_CRF", 21, 16, 28),
            encoder_preset=preset,
            dub_fallback=enabled("DUB_FALLBACK"),
            upload_mode=upload_mode,
            upload_timeout=number("UPLOAD_TIMEOUT", 1800, 30, 14400),
            prepare_timeout=number("PREPARE_TIMEOUT", 300, 30, 3600),
            delete_trigger=enabled("DELETE_DOWNLOAD_TRIGGER"),
            channel_id=number("CHANNEL_ID", 0, 0, 2**64 - 1),
            upload_mb=number("UPLOAD_LIMIT_MB", 1000, 1, 2000),
            quality=number("OUTPUT_HEIGHT", 1080, 144, 2160),
            subtitle_mode=mode,
            max_episodes=number("MAX_EPISODES", 1000, 1, 10000),
            max_temp_bytes=number("MAX_TEMP_GIB", 8, 1, 1000) * 1024**3,
            operation_timeout=number("OPERATION_TIMEOUT", 3600, 60, 86400),
            resolve_timeout=number("RESOLVE_TIMEOUT", 60, 10, 300),
            delay=number("UPLOAD_DELAY", 2, 1, 300),
            attempts=number("EPISODE_ATTEMPTS", 3, 1, 5),
            max_consecutive_failures=number("MAX_CONSECUTIVE_FAILURES", 3, 1, 100),
            request_interval=number("REQUEST_INTERVAL", 0.25, 0.1, 10, float),
            rate_limit_cooldown=number("RATE_LIMIT_COOLDOWN", 300, 60, 3600),
            rate_limit_retries=number("RATE_LIMIT_RETRIES", 2, 0, 5),
            status_interval=number("STATUS_INTERVAL", 8, 5, 120),
            auto_resume=enabled("AUTO_RESUME"),
            auto_compress=enabled("AUTO_COMPRESS"),
            subtitle_fallback=False,
            keep_downloads=enabled("KEEP_DOWNLOADS", False),
            headless=enabled("HEADLESS"),
        )
