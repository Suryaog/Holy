from __future__ import annotations

from fractions import Fraction


def video_filter(video, quality, burn=False):
    width, height = int(video["width"]), int(video["height"])
    try:
        sar = float(
            Fraction(str(video.get("sample_aspect_ratio", "1:1")).replace(":", "/"))
        )
    except (ValueError, ZeroDivisionError):
        sar = 1.0
    if sar <= 0:
        sar = 1.0
    aspect = width * sar / height
    rotation = video.get("tags", {}).get("rotate", 0)
    for side in video.get("side_data_list", []):
        if "rotation" in side:
            rotation = side["rotation"]
    if abs(round(float(rotation))) % 180 == 90:
        aspect = 1 / aspect

    canvas_height = max(18, int(quality) // 18 * 18)
    canvas_width = canvas_height // 9 * 16
    fitted_height = min(canvas_height, canvas_width / aspect)
    fitted_width = fitted_height * aspect
    width = max(2, min(canvas_width, round(fitted_width / 2) * 2))
    height = max(2, min(canvas_height, round(fitted_height / 2) * 2))
    filters = ["fps=24", f"scale={width}:{height}:flags=fast_bilinear", "setsar=1"]
    if burn:
        # libass's WebVTT conversion uses a 288-unit reference height.
        font_size = 14 * canvas_height / height
        margin = round(36 * canvas_height / height)
        style = (
            f"FontName=Liberation Sans,FontSize={font_size:.2f},"
            "PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,"
            "BackColour=&H00000000,BorderStyle=3,Outline=1,Shadow=0,"
            f"MarginV={margin},Alignment=2"
        )
        filters.append(f"subtitles=subtitles.vtt:fontsdir=fonts:force_style='{style}'")
    filters.append(
        f"pad={canvas_width}:{canvas_height}:(ow-iw)/2:(oh-ih)/2:color=black"
    )
    return ",".join(filters)
