# ANIMAX 2.1

Download inclusive MAL episode ranges and upload one whole MP4 per episode with discord.py-self 2.1.0. Videos remain sequential; no splitting.

## Update your installation

Stop the running process. Extract this release separately, then update your existing directory:

```bash
sudo systemctl stop animax
unzip animax-v2.1.zip
sudo python3 animax-v2.1/apply_update.py --target /Holy/animaxv1
sudo systemctl start animax
```

The updater moves production code into `animax/`, retires the old loose modules and backs them up under `.release-backups/`. It keeps `.env`, `anime.json`, cooldowns, downloaded files and your existing service path. Do not run both installations.

For detached execution, use the old `service.py stop-detached` before updating. Afterwards use:

```bash
python3 /Holy/animaxv1/manage.py service detach
```

## New installation

Python 3.11 or newer is recommended. On Ubuntu/Debian:

```bash
unzip animax-v2.1.zip
cd animax-v2.1
bash install.sh
# Edit .env locally. Never share your token.
sudo python3 manage.py service install
```

`python3 bot.py` runs in the foreground. `python3 manage.py service detach` survives SSH logout without systemd, but not a reboot. Run only one mode. The bootstrap installs missing Python packages and Chromium; FFmpeg and native libraries need the installer or your OS package manager.

## Changes

- Output defaults to a 1920×1080, 24 fps H.264/AAC MP4. The complete picture retains its aspect ratio inside black padding.
- A quality-based encode targets roughly 400 MB, with a 500 MB output ceiling by default. Simple episodes may be smaller. File size and perceptual quality depend on the source; this is lossy compression, not a lossless guarantee.
- Two encoding threads, one filter thread, limited reference/look-ahead frames, and no open browser during download/encoding reduce resource overlap.
- Caption wording and timing come from the selected English source track. The smaller Liberation Sans font is Arial-compatible; it is bundled with its license. Black caption backgrounds stay opaque and burned in.
- Preparation shows `**One Piece** | \`E1\` | Enhancing | \`0:1\``. The timer counts elapsed minutes:seconds, not remaining time, and updates at `STATUS_INTERVAL`.
- Video captions no longer contain a download hyperlink. New uploads need no follow-up caption edit. Older Discord messages are unchanged.
- `.reset` asks for a short confirmation code before clearing local history, jobs and downloaded videos.

The profile uses new environment keys so an older `QUALITY=720` or `ENCODER_PRESET=ultrafast` does not silently override it. See [encoding settings](docs/ENCODING.md).

## Commands

```text
download, status, cancel, resume, history, search, getlist, reset, help
```

Use `.help <name>` for syntax.

```text
.download 21 dub 1 100
.search eisode 1 onepimse
.getlist
.reset
```

`.getlist` attaches `anime.json` without accompanying text. `.search` returns up to five local uploaded-message matches. Videos reply to the nearest earlier uploaded episode in the same anime/account/destination. Dub-to-sub fallback requires positive missing-source evidence and is labeled.

When `CHANNEL_ID` is nonzero, automatic episode statuses stay in the command channel after upload. The accepted `.download` trigger is still deleted unless `DELETE_DOWNLOAD_TRIGGER=false`. Failed or uncertain uploads keep their statuses.

## Layout

```text
bot.py              startup
manage.py           service, doctor and migration commands
apply_update.py     code-only updater
animax/             application modules
assets/fonts/       bundled caption fonts and license
config/             example history and title overrides
docs/               encoding and operating notes
```

Runtime `.env`, `anime.json`, `downloads/`, `logs/` and cooldown files remain at the project root for upgrade compatibility. They are not in the ZIP. Tests are kept outside the release.

## Validation

64 automated checks passed on Python 3.13/Linux, including real FFmpeg/HLS processing, 1080p/24 fps output, caption/padding pixels, reset rollback/recovery, streamed journal export, and mocked Discord command/upload flows. Ruff checks, installer shell syntax, and Python 3.10 source-syntax checks also passed. A syntax check is not a full Python 3.10 runtime test.

The approved anti-slop findings were fixed; the scoped PASS report is in `anti-slop/audit-002-2026-10-15.md`. Tests and their generated media/logs are excluded from the ZIP.

Read [operations](docs/OPERATIONS.md) before resetting or retrying an uncertain upload. Real Discord uploads and the account's stated 1 GB entitlement have not been tested with this release. No program can guarantee provider availability or successful uploads.

Discord prohibits automated normal user accounts and may terminate an account: https://support.discord.com/hc/en-us/articles/115002192352-Automated-User-Accounts-Self-Bots . An official bot account is the compliant alternative. Only redistribute media you are authorized to share.
