#!/usr/bin/env python3
"""Stop ANIMAX, then run: python3 apply_update.py --target /path/to/installation."""

from __future__ import annotations

import argparse
import ast
import json
import os
import shutil
import stat
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VERSION = "2.1.0"
MODULES = (
    "__init__",
    "bootstrap",
    "bot",
    "commands",
    "diagnostics",
    "doctor",
    "downloader",
    "encoding",
    "job",
    "media",
    "metadata",
    "migrate",
    "rate_limits",
    "reset",
    "resolver",
    "search",
    "service",
    "settings",
    "storage",
    "terminal",
    "upload",
)
FILES = (
    "bot.py",
    "manage.py",
    "apply_update.py",
    "install.sh",
    "requirements.txt",
    ".env.example",
    ".gitignore",
    "README.md",
    "docs/ENCODING.md",
    "docs/OPERATIONS.md",
    "anti-slop/audit-001-2026-10-15.md",
    "anti-slop/audit-002-2026-10-15.md",
    "config/anime.example.json",
    "config/title_overrides.example.json",
    "assets/fonts/LICENSE.txt",
    *(
        f"assets/fonts/LiberationSans-{style}.ttf"
        for style in ("Regular", "Bold", "Italic", "BoldItalic")
    ),
    *(f"animax/{name}.py" for name in MODULES),
)
LEGACY_FILES = (
    "bootstrap.py",
    "terminal.py",
    "storage.py",
    "resolver.py",
    "media.py",
    "metadata.py",
    "downloader.py",
    "rate_limits.py",
    "diagnostics.py",
    "doctor.py",
    "upload.py",
    "service.py",
    "migrate.py",
    "search.py",
    "anime.example.json",
    "title_overrides.example.json",
)


def checked_path(target: Path, name: str):
    path = target
    for part in Path(name).parts:
        path = path / part
        if path.is_symlink():
            raise RuntimeError(f"Refusing a symlink in update path: {name}")
    return path


def install(target: Path):
    target = target.expanduser().resolve()
    if target == ROOT:
        raise RuntimeError(
            "Use --target for the existing installation, not the extracted release."
        )
    if not (target / "bot.py").is_file():
        raise RuntimeError("The target must contain an existing bot.py.")
    payload = {}
    for name in FILES:
        source = ROOT / name
        if not source.is_file():
            raise RuntimeError(f"Incomplete release: {name}")
        data = source.read_bytes()
        if name.endswith(".py"):
            ast.parse(data.decode("utf-8"), filename=name)
        checked_path(target, name)
        payload[name] = data
    for name in LEGACY_FILES:
        checked_path(target, name)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = target / ".release-backups" / f"v{VERSION}-{stamp}-{uuid.uuid4().hex[:6]}"
    if (target / ".release-backups").is_symlink():
        raise RuntimeError("Refusing a symlinked backup directory.")
    backup.mkdir(parents=True, mode=0o700)
    names = tuple(dict.fromkeys((*FILES, *LEGACY_FILES)))
    existed = {name: (target / name).exists() for name in names}
    for name in names:
        if existed[name]:
            destination = backup / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target / name, destination)
    replaced = []
    owner = target.stat()
    try:
        for name, data in payload.items():
            destination = target / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            previous = destination.stat() if destination.exists() else owner
            mode = (
                stat.S_IMODE(destination.stat().st_mode)
                if destination.exists()
                else stat.S_IMODE((ROOT / name).stat().st_mode)
            )
            descriptor, temporary = tempfile.mkstemp(
                prefix=".release-", dir=destination.parent
            )
            try:
                with os.fdopen(descriptor, "wb") as file:
                    file.write(data)
                    file.flush()
                    os.fsync(file.fileno())
                os.chmod(temporary, mode)
                if hasattr(os, "geteuid") and os.geteuid() == 0:
                    os.chown(temporary, previous.st_uid, previous.st_gid)
                    parent = destination.parent
                    while parent != target:
                        os.chown(parent, owner.st_uid, owner.st_gid)
                        parent = parent.parent
                os.replace(temporary, destination)
                replaced.append(name)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
        for name in LEGACY_FILES:
            if existed[name]:
                (target / name).unlink()
                replaced.append(name)
        (backup / "manifest.json").write_text(
            json.dumps({"version": VERSION, "files_existed": existed}, indent=2)
        )
    except BaseException:
        for name in reversed(replaced):
            if existed[name]:
                shutil.copy2(backup / name, target / name)
            else:
                (target / name).unlink(missing_ok=True)
        raise
    return backup


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", type=Path, required=True)
    args = parser.parse_args()
    backup = install(args.target)
    print(f"Installed ANIMAX {VERSION}. Code backup: {backup}")
    print(
        "Settings, history, cooldowns and cached videos were preserved. Start your existing service."
    )


if __name__ == "__main__":
    main()
