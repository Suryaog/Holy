from __future__ import annotations

import asyncio
import contextlib
import json
import shutil
import sys
import os
import signal
from pathlib import Path

from resolver import Stream, choose_caption
from diagnostics import error_hint, error_summary
from rate_limits import RateLimitError


class MediaError(RuntimeError):
    pass


class MediaProcessError(MediaError):
    def __init__(self, program: str, exit_code: int, output: str):
        self.exit_code = exit_code
        self.program = program
        self.summary = error_summary(output)
        self.hint = error_hint(output)
        super().__init__(f"{program} exited with code {exit_code}:\n{self.summary}\n{self.hint}")


def log_tail(path: Path, start: int = 0, count: int = 16000) -> str:
    with path.open("rb") as file:
        file.seek(max(start, path.stat().st_size - count))
        return file.read().decode("utf-8", "replace")


async def run_process(args: list[str], cwd: Path, *, timeout: float = 3600,
                      max_bytes: int = 8 * 1024**3, progress_file: Path | None = None, on_progress=None) -> str:
    """No shell. Kill/reap subprocesses on timeout, disk exhaustion or cancellation."""
    log = cwd / "process.log"
    start_offset = log.stat().st_size if log.exists() else 0
    with log.open("ab") as output:
        log.chmod(0o600)
        process = await asyncio.create_subprocess_exec(
            *args, cwd=str(cwd), stdout=output, stderr=asyncio.subprocess.STDOUT, start_new_session=(os.name != "nt"))
        waiter = asyncio.create_task(process.wait())
        deadline = asyncio.get_running_loop().time() + timeout
        try:
            while not waiter.done():
                if asyncio.get_running_loop().time() >= deadline:
                    raise MediaError("Media operation timed out.")
                usage = sum(p.stat().st_size for p in cwd.rglob("*") if p.is_file())
                if usage > max_bytes or shutil.disk_usage(cwd).free < 256 * 1024**2:
                    raise MediaError("Temporary-storage budget exceeded or disk nearly full.")
                if progress_file and on_progress and progress_file.exists():
                    try:
                        on_progress(json.loads(progress_file.read_text()))
                    except (ValueError, OSError):
                        pass
                await asyncio.wait({waiter}, timeout=0.5)
            if waiter.result() != 0:
                output.flush()
                program = "yt-dlp" if len(args) > 2 and (args[1:3] == ["-m", "yt_dlp"] or Path(args[1]).name == "downloader.py") else Path(args[0]).name
                raise MediaProcessError(program, waiter.result(), log_tail(log, start_offset))
        finally:
            if process.returncode is None:
                with contextlib.suppress(ProcessLookupError):
                    if os.name != "nt":
                        os.killpg(process.pid, signal.SIGTERM)
                    else:
                        process.terminate()
                try:
                    await asyncio.wait_for(asyncio.shield(waiter), 5)
                except asyncio.TimeoutError:
                    with contextlib.suppress(ProcessLookupError):
                        if os.name != "nt":
                            os.killpg(process.pid, signal.SIGKILL)
                        else:
                            process.kill()
                    await waiter
            if not waiter.done():
                await waiter
    if progress_file and on_progress and progress_file.exists():
        with contextlib.suppress(ValueError, OSError):
            on_progress(json.loads(progress_file.read_text()))
    # Read only a bounded tail, not an entire noisy subprocess log.
    return log_tail(log, start_offset)


async def probe(path: Path) -> dict:
    process = await asyncio.create_subprocess_exec(
        "ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", str(path),
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    try:
        stdout, _ = await asyncio.wait_for(process.communicate(), 30)
        if process.returncode:
            raise MediaError("FFprobe could not read the downloaded video.")
        result = json.loads(stdout)
        if not any(s.get("codec_type") == "video" for s in result.get("streams", [])):
            raise MediaError("Download contains no video stream.")
        if float(result["format"].get("duration", 0)) <= 0:
            raise MediaError("Downloaded video has no valid duration.")
        return result
    finally:
        if process.returncode is None:
            with contextlib.suppress(ProcessLookupError):
                process.kill()
            await process.communicate()


async def write_cookie_file(stream: Stream, cookie_file: Path):
    lines = ["# Netscape HTTP Cookie File"]
    for cookie in await stream.context.cookies():
        lines.append("\t".join([cookie["domain"], str(cookie["domain"].startswith(".")).upper(),
                                cookie["path"], str(cookie["secure"]).upper(),
                                str(max(0, int(cookie.get("expires", 0)))),
                                cookie["name"], cookie["value"]]))
    cookie_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    cookie_file.chmod(0o600)


async def download(stream: Stream, work: Path, language: str, *, quality: int = 720,
                   subtitle_mode: str = "burn", max_bytes: int = 8 * 1024**3,
                   timeout: int = 3600, request_interval: float = 0.25, on_progress=None, on_phase=None, subtitle_fallback: bool = True) -> tuple[Path, str | None]:
    work.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(work).free < 512 * 1024**2:
        raise MediaError("At least 512 MiB of free disk space is required.")
    cookie_file = work / "cookies.txt"
    await write_cookie_file(stream, cookie_file)
    rate_report = work / "rate-limit.json"
    progress_file = work / "progress.json"
    progress_file.unlink(missing_ok=True)
    args = [sys.executable, str(Path(__file__).with_name("downloader.py")),
            "--mp-request-interval", str(request_interval), "--mp-rate-limit-report", str(rate_report),
            "--mp-progress-file", str(progress_file),
            "--ignore-config", "--no-playlist", "--no-progress",
            "--no-warnings", "--socket-timeout", "30", "--retries", "0", "--fragment-retries", "0",
            "--abort-on-unavailable-fragments", "--concurrent-fragments", "1",
            "--cookies", str(cookie_file), "--hls-use-mpegts", "--remux-video", "mp4",
            "--merge-output-format", "mp4", "--max-filesize", str(max_bytes // 2),
            "-f", f"bv*[height<={quality}]+ba/b[height<={quality}]/b",
            "-o", str(work / "source.%(ext)s")]
    for key, value in stream.headers.items():
        args += ["--add-header", f"{key}:{value}"]
    args += ["--", stream.url]
    try:
        await run_process(args, work, timeout=timeout, max_bytes=max_bytes,
                          progress_file=progress_file, on_progress=on_progress)
    except MediaProcessError as exc:
        if rate_report.exists():
            data = json.loads(rate_report.read_text())
            if data.get("status") == 429:
                raise RateLimitError(data.get("retry_after")) from exc
        if "429" in exc.summary or "too many requests" in exc.summary.lower():
            raise RateLimitError() from exc
        raise
    finally:
        cookie_file.unlink(missing_ok=True)
    source = work / "source.mp4"
    if not source.exists() or not source.stat().st_size:
        raise MediaError("Downloader did not produce source.mp4 (possibly over the disk-size limit).")
    original_info = await probe(source)
    if on_phase: on_phase("Preparing MP4")
    # Native HLS may leave MPEG-TS bytes under an .mp4 filename, particularly
    # with --hls-use-mpegts. Always create a real, fast-start MP4 and discard
    # non-media data streams (for example timed ID3) before Discord upload.
    normalized = work / "whole.mp4"
    try:
        await run_process([
            "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "warning", "-y", "-i", str(source),
            "-map", "0:v:0", "-map", "0:a:0?", "-map", "0:s?",
            "-c:v", "copy", "-c:a", "copy", "-c:s", "mov_text",
            "-movflags", "+faststart", str(normalized)
        ], work, timeout=timeout, max_bytes=max_bytes)
    except MediaProcessError:
        # Local fallback only; no extra CDN requests and no fragment skipping.
        if on_phase: on_phase("Compatibility encoding")
        await run_process([
            "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "warning", "-y", "-i", str(source),
            "-map", "0:v:0", "-map", "0:a:0?", "-c:v", "libx264", "-preset", "veryfast",
            "-crf", "23", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k",
            "-movflags", "+faststart", str(normalized)
        ], work, timeout=timeout, max_bytes=max_bytes)
    normalized_info = await probe(normalized)
    if "mp4" not in normalized_info["format"].get("format_name", "").split(","):
        raise MediaError("Final video is not a real MP4 container.")
    if abs(float(normalized_info['format']['duration']) - float(original_info['format']['duration'])) > 3:
        raise MediaError('MP4 duration changed unexpectedly; refusing a potentially incomplete episode.')
    source.unlink()
    source = normalized
    note = None
    if language == "sub" and subtitle_mode != "none":
        track = choose_caption(stream.tracks)
        if track is None:
            note = "No external English caption track was advertised; subtitles may be hardcoded or unavailable."
        else:
            subtitle = work / "subtitles.vtt"
            subtitle.write_bytes(await stream.caption_bytes(track))
            result = work / "episode.mp4"
            args = ["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "warning", "-y", "-i", str(source)]
            if on_phase: on_phase("Burning subtitles" if subtitle_mode == "burn" else "Muxing subtitles")
            if subtitle_mode == "burn":
                args += ["-map", "0:v:0", "-map", "0:a:0?", "-vf", f"scale=-2:'min({quality},ih)',subtitles=subtitles.vtt",
                         "-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-pix_fmt", "yuv420p",
                         "-c:a", "aac", "-b:a", "128k"]
            elif subtitle_mode == "mux":
                args += ["-i", str(subtitle), "-map", "0:v:0", "-map", "0:a:0?", "-map", "1:0",
                         "-c:v", "copy", "-c:a", "copy", "-c:s", "mov_text",
                         "-metadata:s:s:0", "language=eng", "-disposition:s:0", "default"]
            else:
                raise ValueError("SUBTITLE_MODE must be burn, mux or none.")
            args += ["-movflags", "+faststart", str(result)]
            try:
                await run_process(args, work, timeout=timeout, max_bytes=max_bytes)
            except MediaProcessError:
                if subtitle_mode != "burn" or not subtitle_fallback:
                    raise
                if on_phase: on_phase("Soft-subtitle fallback")
                await run_process(["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "warning", "-y",
                    "-i", str(source), "-i", str(subtitle), "-map", "0:v:0", "-map", "0:a:0?", "-map", "1:0",
                    "-c:v", "copy", "-c:a", "copy", "-c:s", "mov_text", "-metadata:s:s:0", "language=eng",
                    "-disposition:s:0", "default", "-movflags", "+faststart", str(result)],
                    work, timeout=timeout, max_bytes=max_bytes)
                note = 'Subtitle burning failed; a selectable English track was embedded. Discord may not display it; use VLC.'
            await probe(result)
            source.unlink()
            source = result
    (work/'ready.json').write_text(json.dumps({'file': source.name, 'language': language,
        'quality': quality, 'subtitle_mode': subtitle_mode, 'subtitle_fallback': subtitle_fallback, 'note': note}))
    return source, note


async def cached_video(work: Path, language: str, quality: int, subtitle_mode: str, subtitle_fallback=True):
    marker = work/'ready.json'
    if not marker.exists(): return None
    try:
        data = json.loads(marker.read_text())
        if (data['language'], data['quality'], data['subtitle_mode']) != (language, quality, subtitle_mode):
            return None
        if data.get('subtitle_fallback', True) != subtitle_fallback: return None
        source = work/data['file']
        if source.parent.resolve() != work.resolve(): return None
        await probe(source)
        return source, data.get('note')
    except (ValueError, KeyError, OSError, MediaError):
        return None


async def fit_whole_video(source: Path, limit: int, *, timeout=3600, max_bytes=8*1024**3):
    if source.stat().st_size <= limit:
        return source
    duration = float((await probe(source))['format']['duration'])
    for attempt in range(2):
        bitrate = int((limit * 8 / duration * (0.88 if attempt == 0 else 0.70)) - 128000)
        if bitrate < 180000:
            raise UploadTooLarge('Whole episode is too long to fit this cap at usable quality; no splitting performed.')
        result = source.parent/'fitted.mp4'
        await run_process(['ffmpeg','-nostdin','-hide_banner','-loglevel','warning','-y','-i',str(source),
            '-map','0:v:0','-map','0:a:0?','-map','0:s?', '-c:v','libx264','-preset','veryfast',
            '-b:v',str(bitrate),'-maxrate',str(bitrate),'-bufsize',str(bitrate*2),'-pix_fmt','yuv420p',
            '-c:a','aac','-b:a','128k','-c:s','mov_text','-movflags','+faststart',str(result)],
            source.parent,timeout=timeout,max_bytes=max_bytes)
        actual = await probe(result)
        if abs(float(actual['format']['duration'])-duration) > 3:
            raise MediaError('Compressed-video duration mismatch. No truncated file will be uploaded.')
        if result.stat().st_size <= limit: return result
    raise UploadTooLarge('Whole episode is still above the configured cap after compression. No splitting performed.')


class UploadTooLarge(MediaError):
    pass


def check_upload_size(source: Path, limit: int) -> Path:
    """Require one whole MP4; never split, truncate or silently compress it."""
    if limit < 1:
        raise ValueError("Upload limit must be positive.")
    size = source.stat().st_size
    if size > limit:
        raise UploadTooLarge(
            f"Whole episode is {size / 1_000_000:.1f} MB; configured cap is "
            f"{limit / 1_000_000:.1f} MB. No file uploaded and no splitting performed.")
    return source
