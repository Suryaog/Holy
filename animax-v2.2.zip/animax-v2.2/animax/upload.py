"""Discord cloud-attachment upload with explicit phases and bounded confirmation.
Never automatically resend a message after an ambiguous confirmation failure.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path

import discord

from .diagnostics import redact

log = logging.getLogger("animax.upload")


class UploadFailure(RuntimeError):
    def __init__(
        self,
        message,
        *,
        stage,
        outcome_unknown=False,
        status=None,
        code=None,
        details=None,
    ):
        self.stage, self.outcome_unknown = stage, outcome_unknown
        self.status, self.code = status, code
        self.details = details
        super().__init__(message)


class JournalCommitFailure(UploadFailure):
    pass


def write_report(path: Path, report: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    temporary.chmod(0o600)
    temporary.replace(path)


async def upload_episode(
    target,
    source: Path,
    caption: str,
    *,
    filename: str,
    report_path: Path,
    timeout=1800,
    mode="auto",
    on_phase=None,
    reference=None,
):
    """Use public discord.py-self 2.1 CloudFile support for normal large uploads."""
    has_cloud = callable(getattr(target, "upload_files", None))
    chosen = (
        "cloud"
        if mode == "auto" and has_cloud
        else "multipart"
        if mode == "auto"
        else mode
    )
    if chosen not in {"cloud", "multipart"}:
        raise ValueError("UPLOAD_MODE must be auto, cloud or multipart.")
    if chosen == "cloud" and not has_cloud:
        raise UploadFailure(
            "This channel/client does not expose cloud attachments. Repair discord.py-self or explicitly select multipart.",
            stage="preflight",
        )
    report = {
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "stage": "preflight",
        "method": chosen,
        "channel_id": str(target.id),
        "filename": filename,
        "file_size_bytes": source.stat().st_size,
        "timeout_seconds": timeout,
        "message_confirmed": False,
    }
    write_report(
        report_path, report
    )  # Fail before any send if diagnostic storage is unwritable.
    started = time.monotonic()
    posting = False
    send_options = {}
    if reference is not None:
        send_options = {"reference": reference, "mention_author": False}
        report["reply_to_message_id"] = str(reference.message_id)
    attachment = discord.File(str(source), filename=filename)

    def phase(name):
        report.update(stage=name, elapsed_seconds=round(time.monotonic() - started, 2))
        write_report(report_path, report)
        log.info(
            "Upload stage=%s channel=%s bytes=%s file=%s",
            name,
            target.id,
            report["file_size_bytes"],
            filename,
        )
        if on_phase:
            on_phase(name)

    def remaining():
        value = timeout - (time.monotonic() - started)
        if value <= 0:
            raise asyncio.TimeoutError()
        return value

    try:
        if chosen == "cloud":
            phase("Uploading")
            cloud_files = await asyncio.wait_for(
                target.upload_files(attachment), timeout=remaining()
            )
            if len(cloud_files) != 1:
                raise RuntimeError(
                    "Discord did not return exactly one pre-uploaded attachment."
                )
            phase("Posting message")
            posting = True
            sent = await asyncio.wait_for(
                target.send(caption, file=cloud_files[0], **send_options),
                timeout=remaining(),
            )
        else:
            phase("Uploading")
            posting = True
            sent = await asyncio.wait_for(
                target.send(caption, file=attachment, **send_options),
                timeout=remaining(),
            )
        report.update(
            stage="message_confirmed",
            message_confirmed=True,
            message_id=str(sent.id),
            jump_url=getattr(sent, "jump_url", None),
            elapsed_seconds=round(time.monotonic() - started, 2),
        )
        # Once Discord has accepted the message, a diagnostic write failure must not
        # turn a successful send into a retry. The caller commits its message ID next.
        try:
            write_report(report_path, report)
        except OSError:
            log.exception(
                "Upload confirmed as message %s but diagnostic report could not be updated",
                sent.id,
            )
        log.info(
            "UPLOAD_CONFIRMED channel=%s message=%s bytes=%s",
            target.id,
            sent.id,
            report["file_size_bytes"],
        )
        return sent
    except asyncio.CancelledError:
        report.update(
            stage="cancelled",
            outcome_unknown=posting,
            elapsed_seconds=round(time.monotonic() - started, 2),
        )
        try:
            write_report(report_path, report)
        except OSError:
            log.exception("Could not save cancelled upload report")
        raise
    except Exception as exc:
        status = getattr(exc, "status", None)
        code = getattr(exc, "code", None)
        details = redact(str(getattr(exc, "text", None) or exc))[:1800]
        ambiguous = posting and (
            not isinstance(exc, discord.HTTPException)
            or status is not None
            and status >= 500
        )
        if isinstance(exc, asyncio.TimeoutError):
            details = f"The configured {timeout}s upload/confirmation deadline expired."
        report.update(
            error_type=type(exc).__name__,
            http_status=status,
            discord_error_code=code,
            error=details,
            outcome_unknown=ambiguous,
            elapsed_seconds=round(time.monotonic() - started, 2),
        )
        try:
            write_report(report_path, report)
        except OSError:
            log.exception("Could not save upload failure report")
        if ambiguous:
            message = "Discord did not confirm the final message. It may already exist: check the destination before retrying. Cached video was kept."
        elif status in {401, 403} or code in {50001, 50013}:
            message = "Discord denied this upload. Check account access and Attach Files/Send Messages permissions in the destination."
        elif status == 413 or code == 40005:
            message = "Discord rejected the file size. Set UPLOAD_LIMIT_MB to the actual limit allowed for this account; no video was split."
        elif status == 429:
            message = "Discord rate-limited the upload. Stop retrying for now; the video cache is retained."
        else:
            message = f"Upload failed during {report['stage']}. The video cache is retained; inspect the per-episode upload JSON report."
        raise UploadFailure(
            message,
            stage=report["stage"],
            outcome_unknown=ambiguous,
            status=status,
            code=code,
            details=details,
        ) from exc
    finally:
        attachment.close()
