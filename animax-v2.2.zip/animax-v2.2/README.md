<div align="center">

# ANIMAX

**Whole episodes. Source frame rates. Quality-first encoding.**

[Quick start](#quick-start) · [Commands](#commands) · [Encoding](docs/ENCODING.md) · [Operations](docs/OPERATIONS.md)

</div>

ANIMAX downloads inclusive MAL episode ranges and sends one complete MP4 per episode to Discord. Version **2.2** adds quality-first encoding, source-FPS preservation, runtime settings, and channel-based history recovery.

| Video | Workflow |
| :--- | :--- |
| H.264 / AAC with a 1080p default canvas | Sequential uploads with episode reply chains |
| Original frame rate, including 23.976 fps | Persistent history and resumable jobs |
| Full-frame padding without cropping | Fuzzy search for uploaded episodes |
| Outlined sub captions; boxed dub captions | SSH-safe service or detached execution |

## Quick start

Python **3.11+** is recommended. On Ubuntu or Debian:

```bash
git clone --branch animax https://github.com/Suryaog/Holy.git
cd Holy
bash install.sh
```

Edit `.env` locally with your account token and destination:

```dotenv
DISCORD_TOKEN=your_account_token
CHANNEL_ID=0
```

Then choose one execution mode:

```bash
# Foreground
.venv/bin/python bot.py

# Survives SSH logout and starts at boot
sudo python3 manage.py service install

# Without systemd; survives logout, not a reboot
python3 manage.py service detach
```

Using the release ZIP instead? Extract it, enter its directory, and start at `bash install.sh`.

## Commands

```text
download, status, cancel, resume, history, search, getlist, reset, refetch, settings, help
```

| Command | Example |
| :--- | :--- |
| Download an inclusive range | `.download 21 dub 1 100` |
| Inspect or stop work | `.status` · `.cancel` |
| Resume saved work | `.resume` |
| Search uploaded episodes | `.search One piece episode 1` |
| Export history | `.getlist` |
| Recover missing/empty history | `.refetch #channel` or `.refetch 123456789012345678` |
| Change an encoding option | `.settings quality 1080` |
| Clear local history/cache, after confirmation | `.reset` |

Command triggers are deleted by default. If deletion fails or is disabled, responses reply to the trigger without pinging its author. `.getlist` sends only the JSON attachment. Video captions have no download hyperlink.

## Picture quality

The default profile uses **CRF 19 / x264 fast**, without a duration-based bitrate ceiling. Action scenes can use more bits instead of being squeezed into a fixed 400 MB budget. Files can be larger; a size limit is an upload guard, not permission to silently lower quality.

```text
.settings compress quality
.settings preset fast
.settings crf 19
.settings threads 4
.settings fps source
```

`ultrafast` saves encoding time but needs more bits. Under a tight bitrate ceiling it can visibly degrade motion. Use `veryfast` if `fast` takes too long, or try CRF 18 for more detail. Settings are validated before saving and survive restarts in `settings.json`.

The source may be 23.976, 24, 29.97, 30, or 60 fps. ANIMAX probes each file and preserves its timing by default. It does not guess a frame rate from the anime title or speed up 23.976 fps material to 24.

Encoding is still lossy. Existing source blockiness cannot be recovered, and no fixed file size guarantees unchanged quality. [Encoding options and trade-offs →](docs/ENCODING.md)

## Project layout

```text
animax/          application, media pipeline and command handlers
assets/fonts/    caption fonts and their license
config/          example data files
docs/            encoding, operation and validation notes
tests/           regression and media tests (source checkout)
.github/         CI workflow
bot.py           application entry point
manage.py        service, diagnostics and migration commands
```

Runtime settings, credentials, histories, logs, caches and ZIP archives are excluded from Git. Test files are excluded from the deployment ZIP.

## Development

From a source checkout:

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements-dev.txt
.venv/bin/python -m pytest
.venv/bin/ruff check .
.venv/bin/ruff format --check .
```

Tests use real FFmpeg for media processing and mocks for Discord interactions. They do not log into an account. [Validation details](docs/VALIDATION.md)

> ANIMAX uses `discord.py-self`. Discord prohibits automated user accounts and may terminate them; an official bot account is the compliant alternative. Only download or redistribute media you are authorized to share. Keep your token private. Real Discord uploads and account upload entitlement have not been verified for this release.
