# Validation

## Local checks

94 tests passed on Python 3.13/Linux. Media tests use real FFmpeg; Discord tests use mocks, not an account login.

Coverage includes:

- Source-rate preservation at 24000/1001, 24, 30000/1001, 30 and 60 fps.
- 1080p H.264 output, full-frame padding and single-pass enhancement.
- Actual pixel checks distinguishing transparent/outlined sub captions from opaque dub boxes.
- Quality mode without a bitrate ceiling and without automatic size-fitting recompression.
- Settings validation, restart persistence, channel access checks, secret-field rejection and atomic-save failure.
- Command-trigger deletion and reply fallback when deletion fails or is disabled.
- Refetch from exports/uploads, own-account filtering, sub-fallback recovery, latest-message ordering and no job resurrection.
- Refetch rejection of populated history and no partial commit after network failure, timeout or cancellation.
- Reset confirmation, rollback, restart recovery, symlink refusal and episode-1 download after reset.
- Journal/resume, search, attachment-only export, reply chains, cooldowns and uncertain-send handling.

Ruff lint/format checks, installer shell syntax and Python 3.10 AST syntax are checked separately. AST compatibility is not a full Python 3.10 runtime test. The GitHub Actions workflow defines Python 3.11/3.13 jobs; hosted CI has not run from this workspace.

## Motion fixture

A three-second, 1440×1080, 24 fps synthetic moving-pattern source was padded to 1920×1080 and encoded with four threads. The comparison was against the same lossless fixture, including its black padding.

| Profile | SSIM | Encoded bytes |
| --- | ---: | ---: |
| Old-style ultrafast, CRF 23, 1.96 Mb/s VBV ceiling | 0.990156 | 1,133,728 |
| v2.2 fast, CRF 19, no VBV ceiling | 0.998492 | 2,244,784 |

Higher SSIM means closer pixel structure for this fixture. These numbers are not a full-episode bitrate estimate, a subjective anime-quality score, a speed benchmark or a promise of no visible artifacts. The larger output is an expected consequence of removing bitrate starvation.

## Source review

The after-mode review used miqdadbadjuber/anti-slop at commit `b1cdf87d49b1653293d58424516fd80394008345`. No new blocking findings were identified; no global plugin settings were installed.

- R-02 PASS: authored application/docs copy was scanned for prohibited punctuation.
- R-17/R-36/R-38 PASS: measurements identify their fixture and limits; no live-upload, exact-font, lossless-quality or guaranteed speed claim is made.
- R-23/R-31/R-37 PASS: caption/padding direction comes from the supplied screenshots and requirements; font license and encoding/resource trade-offs are documented.
- R-26/R-27/R-35 PASS within local scope: command callbacks and success/empty/error/cancellation paths were exercised. Actual Discord account operations remain untested.
- R-33 PASS: new command, recovery and presentation behavior is implemented in source modules; no source-patching/updater script is shipped.
- Code-comment review PASS: remaining comments describe protocol, concurrency, timing or safety constraints. No decorative comment banners were added.

Website-only navigation/theme/responsive-layout rules are not applicable. Discord owns its client UI; this review does not certify Discord's mobile layout or arbitrary terminal colors.

## Not verified

No live Discord upload, account entitlement check, full live V2.2 episode download, installed systemd service/reboot test or authenticated GitHub push was performed. Provider caption accuracy and upstream picture quality remain external limitations. Logs and generated test media are not shipped in the release ZIP.
