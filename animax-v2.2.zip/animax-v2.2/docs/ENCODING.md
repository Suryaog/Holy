# Encoding

## Quality-first profile

The v2.2 defaults are H.264 High profile, yuv420p, AAC 128 kb/s, CRF 19, x264 `fast`, four encoding/decoding threads, and a 1920×1080 canvas. The source frame rate is preserved.

`compress quality` omits `-maxrate` and `-bufsize`. The encoder can spend more bits on motion, fine textures and effects. The old duration-based ceiling could starve fight scenes, especially with `ultrafast`. This change addresses encoding-induced blockiness; it cannot repair detail already lost in the source.

A quality-mode file above `min(max_size, upload_limit)` is retained and rejected for upload. It is not automatically recompressed at lower quality, even if `reencode` is on. Choose a different quality setting explicitly or increase the allowed cap only if your Discord account supports it. The default cap is 1,000 decimal MB, not a verified entitlement.

For a slower CPU, `preset veryfast` is a useful alternative. More threads can reduce elapsed time but increase CPU/RAM use. Lower CRF means higher requested quality and usually larger files. CRF 18 is a reasonable next step if 19 loses detail; neither is a lossless guarantee.

## Size mode

`.settings compress size` enables the duration-based bitrate budget. `target_size` defaults to 400 MB. This mode trades difficult-scene detail for size and is not the recommended fix for blocky action.

`reencode on` permits a bounded extra size-fitting encode only in size mode. It is off by default. No mode splits or truncates an episode. Simple episodes can be smaller than the target; a minimum file size is not enforced.

## Frame rate

`fps source` adds no FPS filter or output `-r`. Timestamp passthrough avoids an implicit CFR conversion. The ready marker and logs record the probed source/output average frame rates.

Fractional rates are distinct: 24000/1001 is approximately 23.976, not 23 or exactly 24. No screenshot can establish the exact source rate. You can inspect a saved file with:

```bash
ffprobe -v error -select_streams v:0 \
  -show_entries stream=r_frame_rate,avg_frame_rate \
  -of default=noprint_wrappers=1 episode.mp4
```

Explicit overrides are available: `23.976`, `24`, `25`, `29.97`, `30`, `50`, `59.94`, `60`. Fractional options use their exact rational values. Choose `source` unless you intentionally want conversion. Preserving a 60 fps source means processing its 60 frames per second; it does not guarantee lower CPU use.

## Frame and subtitles

The full source display aspect, including sample aspect ratio and rotation, fits inside an even 16:9 black canvas. A 4:3 1080p picture receives side bars, without a crop or stretch-to-fill filter. Bicubic scaling replaces the earlier fast-bilinear scaler. Upscaling a low-resolution source does not add real detail.

Sub videos, including dub-to-sub fallbacks, use white outlined text with **no filled black background**. Dub videos retain opaque black caption boxes. This affects newly burned external captions; boxes already hardcoded upstream cannot be removed safely.

The advertised English WebVTT cue wording and timestamps are not rewritten. Dub/CC-labeled tracks are preferred for dub when available. A generic English translation can still differ from the spoken dub. Missing matching captions are not generated. Liberation Sans is bundled as an Arial-compatible font; browser CSS rendering is not reproduced pixel-for-pixel.

`subtitles burn|mux|none` controls sub videos. Dub always burns an available English track. Burn errors do not silently switch to soft subtitles.

## Resource use

Chromium captures source data/cookies/captions and closes before download/encoding. Native HLS stays single-worker. Video uploads and JSON exports stream from disk rather than loading whole files into Python memory.

The encoder uses three references, three B-frames, twenty look-ahead frames and no synchronous look-ahead queue. The filter graph uses one thread; decoder/encoder thread limits use `threads`. This profile spends more CPU/bits than `ultrafast` to improve compression and motion quality. It is not a whole-process CPU quota or a strict RAM ceiling.

Changing codec/profile settings invalidates incompatible prepared caches. Already uploaded episodes remain completed until an intentional force send or confirmed reset.

## Common settings

| Command field | Environment key | Default |
| --- | --- | --- |
| `quality` | `OUTPUT_HEIGHT` | `1080` |
| `compress` | `COMPRESSION_MODE` | `quality` |
| `preset` | `VIDEO_PRESET` | `fast` |
| `crf` | `VIDEO_CRF` | `19` |
| `threads` | `ENCODE_THREADS` | `4` |
| `fps` | `FRAME_RATE` | `source` |
| `target_size` | `TARGET_SIZE_MB` | `400` |
| `max_size` | `MAX_OUTPUT_MB` | `1000` |
| `upload_limit` | `UPLOAD_LIMIT_MB` | `1000` |
| `reencode` | `ALLOW_SIZE_REENCODE` | `off` |

`.settings` lists every configurable field. `.settings FIELD` shows its current value and valid options. Saved command overrides take precedence over `.env`. Existing `.env` values such as `VIDEO_PRESET=ultrafast` still apply until changed; use the recommended `.settings` commands in the README to replace them.
