# ANIMAX v1-debugged-1

**Whole episodes. Real progress. Persistent history. SSH-safe operation.**

```text
.download 21 dub 1 100
```

Each successful episode is uploaded as **one whole MP4 attachment**, with a caption like:

```text
One Piece | episode : 12
```

No numbered video parts. Default configured attachment cap: **1 GB / 1,000,000,000 bytes**. Discord still enforces your actual account entitlement.

> **No honest implementation can promise 100% success.** Missing episodes, CDN outages, access refusals, rate limits, disk exhaustion, invalid credentials and Discord permissions are outside this program's control. ANIMAX makes failures visible and resumable instead of pretending they succeeded.
>
> Discord prohibits selfbots and can terminate the account. An official bot account is the compliant alternative. [1](https://support.discord.com/hc/en-us/articles/115002192352-Automated-User-Accounts-Self-Bots) Only download/repost media you are authorized to distribute. Never share your token.

## Upgrade your current `/Holy/animaxv1` installation

Stop your existing bot first. Extract this ZIP into a separate directory, then apply only the code update:

```bash
sudo systemctl stop animax
unzip v1-debugged-1.zip
python3 v1-debugged-1/apply_update.py --target /Holy/animaxv1
sudo systemctl start animax
```

If you use detached mode instead of systemd, stop it with `python3 /Holy/animaxv1/service.py stop-detached`, apply the update, then use `python3 /Holy/animaxv1/service.py detach`.

The updater preserves `.env`, **real `anime.json`**, message history, cooldowns, downloaded/cache files, the virtual environment and browser binaries. It backs up replaced code under `.release-backups/`. This release contains `anime.example.json`, **not** an empty `anime.json` that could overwrite your history. No test files are included.

Try `.download 21 dub 1 1` before requesting a long range. If a previous attempt left a verified completed video, it can be reused without downloading it again.

## What changed in this debug release

### One progress message per episode

The automatic message format is:

```text
**One Piece**

Episode : `1/100`

Download Status : `Downloading`

`███████████░░░░░░░░░` **56%**
```

The title is bold when Discord renders it. The denominator is the requested **ending episode number**, so a command requesting episodes 10–20 shows `10/20`, then `11/20`, etc. Estimated totals are labelled; unknown totals are not fabricated.

- Every episode that needs work gets a separate progress message in the **command channel**. Videos go to the configured destination.
- A valid `.download` trigger is deleted after the job is queued. Invalid/rejected commands remain visible with their error. `. download` is also accepted.
- The episode progress message is deleted **only after Discord confirms the final video message and its message ID has been committed to `anime.json`**.
- Failed, cancelled and uncertain uploads retain their status message and cache. A successful retry cleans up tracked older progress messages for that episode too.
- Only messages authored by the logged-in account are deleted. Deletion is best-effort if Discord denies it; a cleanup failure does not make an uploaded video count as failed.
- `.status` uses the same per-episode display. The download bar can be 100% while the status is `Preparing MP4`, `Uploading` or `Posting message`: those stages are not the same as a confirmed upload. Slow preparation/upload stages show elapsed time.

### Upload and preparation diagnostics

The previous code used direct multipart sending. `UPLOAD_MODE=auto` now prefers the public **`discord.py-self` 2.1 cloud-attachment API**: pre-upload the video, then post a message referring to the uploaded attachment. Multipart is used only for clients without that capability, or when you explicitly configure it. The code does not fall back blindly after an access/size denial or uncertain final message response.

The excerpt you shared does **not** establish an upload failure. A Python 3.10 deprecation warning is not a download exception. MPEG-TS `stream 2` / `estimate_timings_from_pts` warnings can concern metadata/timing; they are not automatically fatal. This release still explicitly normalizes the downloaded transport stream to MP4 and excludes non-media data.

New diagnostics distinguish:

1. Raw download completed.
2. Source probe and MP4 preparation completed (real container/duration checks).
3. Video is ready for upload (`VIDEO_READY` in `logs/bot.log`).
4. Cloud upload / message posting started.
5. Discord returned a final message ID (`UPLOAD_CONFIRMED`).
6. The journal was committed; progress-message cleanup may now run.

Subprocess logs now include **START/END, exit code and elapsed time**, so a warning followed by `exit=0` is distinguishable from failure. Probing stderr is retained locally. Fast remux preparation and Discord upload have separate bounded timeouts.

If upload still fails, inspect:

```bash
cat /Holy/animaxv1/logs/upload-21-dub-1.json
tail -n 80 /Holy/animaxv1/logs/bot.log
```

The upload JSON records the method, stage, file size, HTTP status, Discord error code, redacted error and confirmed message ID when available. If no new upload report exists, the job may have stopped **before** the upload stage; check the stage log and per-episode media log. Compare timestamps so an older report is not mistaken for the current attempt.

A final-message timeout/cancellation can be ambiguous: Discord might have accepted it without returning confirmation. Such episodes are marked **Needs review** and are not automatically resent after restart. Check the channel before using `force`. If the message already exists, do not blindly resend it. A journal-write failure after a confirmed message likewise keeps the progress message visible and reports the accepted ID.

New optional settings (defaults apply without editing an existing `.env`):

```dotenv
UPLOAD_MODE=auto
UPLOAD_TIMEOUT=1800
PREPARE_TIMEOUT=300
DELETE_DOWNLOAD_TRIGGER=true
```

`UPLOAD_TIMEOUT` covers upload plus final confirmation. Increase it for a genuinely slow outbound link. `PREPARE_TIMEOUT` limits fast remuxing; long subtitle/compatibility encodes still use `OPERATION_TIMEOUT`. `UPLOAD_MODE=multipart` is an explicit diagnostic alternative, not a way to override account limits.

**The original server-specific failure has not been proven from the truncated excerpt.** This release implements a better-supported upload path and clear diagnostics; real Discord uploads still need validation with your account.

## Quick start — Ubuntu / Debian

Use Python **3.11+ recommended**; Python 3.10 remains supported by this code, but the downloader warns that its support is deprecated.

1. Extract `v1-debugged-1.zip` into a **new directory**.
2. Open a terminal there and run:

```bash
cd v1-debugged-1
bash install.sh
```

3. Edit `.env` locally:

```dotenv
DISCORD_TOKEN=your_account_token
CHANNEL_ID=0
UPLOAD_LIMIT_MB=1000
```

4. Choose how to run:

```bash
# Foreground, with the coloured interactive terminal:
.venv/bin/python bot.py

# Recommended on a VPS: survives SSH logout, restarts after crashes and at boot.
sudo python3 service.py install
```

Do not run both modes simultaneously. The instance lock prevents duplicate upload workers.

If you are already root, omit `sudo`. The systemd installer runs the bot as the **owner of the project directory**. A dedicated non-root account is preferable when practical; ensure that account owns and can write the project and read `.env`.

### Upgrading from the earlier project

Stop the old bot/service first. Keep the new folder separate when migrating. This debug release ships only an `anime.example.json`; it does not overwrite real history.

Before starting ANIMAX, run:

```bash
python3 migrate.py --from /root/mp/megaplay-selfbot
```

This copies `.env`, `state.json`, `anime.json` if present, title overrides and saved cooldowns without printing their contents. It refuses to overwrite non-empty destination settings/history unless you explicitly pass `--replace`; replaced files are backed up. Legacy single-message upload records are imported into `anime.json` on startup. Legacy multipart records are not considered completed whole-video deliveries.

The old `CDN_REQUEST_INTERVAL=2` setting is **not used**. ANIMAX uses `REQUEST_INTERVAL=0.25` by default. Existing saved rate-limit cooldowns are still respected.

## Keep it running after SSH closes

### Recommended: systemd

```bash
sudo python3 service.py install
sudo python3 service.py status
sudo python3 service.py logs
sudo python3 service.py restart
sudo python3 service.py stop
```

Equivalent familiar commands:

```bash
systemctl status animax --no-pager
journalctl -u animax -f
```

The service starts at boot, restarts on runtime failure, and stops retrying invalid configuration/login exits. SIGTERM saves the interrupted job; `AUTO_RESUME=true` resumes it when the same account reconnects. Crash recovery is bounded by systemd's start-rate limits rather than an infinite rapid restart loop.

### No systemd / container fallback

```bash
python3 service.py detach
python3 service.py status-detached
python3 service.py stop-detached
```

Detached mode uses a new process session, closed stdin and file-backed output. SSH logout will not send the bot the shell's hangup. Read `logs/daemon.log` for output. **Detached mode does not provide crash or reboot restart**; use systemd or your container's restart policy for that.

Closing SSH while running plain `python3 bot.py` in the foreground can still stop it. Install the service or explicitly use detached mode.

## Commands

| Command | Action |
|---|---|
| `.download 21 dub 1 100` | Inclusive MAL-based range, dubbed, sequential whole-video uploads |
| `.download 21 sub 1 100` | Subbed version |
| `.download 21 dub 1 100 force` | Resend even if a successful message is recorded |
| `.status` | Current episode, real download progress, stage, counters and cooldown |
| `.cancel` | Stop this job; preserve message history, cache and cooldown |
| `.resume` / `.retry` | Resume the last saved job in its original destination; skip delivered episodes |
| `.history 21` | Summary of locally tracked episodes and deliveries |
| `.help` / `.mphelp` | Command help |

Only your own account's messages trigger commands. One job runs at a time. `CHANNEL_ID=0` uses the command channel; set a positive ID for a fixed destination.

## Progress and terminal

- ANIMAX ASCII banner, coloured phase messages and a live per-episode progress bar on a real terminal.
- Each episode gets its own temporary progress message, edited every eight seconds by default. It is deleted after a confirmed upload and journal commit. `.status` gives an on-demand snapshot.
- Progress uses yt-dlp's reported byte totals, or fragment counts when totals are unavailable. **`~` means estimated.** Unknown totals remain indeterminate rather than showing a fabricated percentage.
- Network speed and ETA are shown when the downloader supplies them.
- `100% downloaded` is **not** `uploaded`: remuxing, subtitle work, compression and uploading are shown as separate stages. Discord's SDK does not expose a reliable upload-byte percentage here, so ANIMAX does not invent one.
- Colour/live cursor animation is disabled for non-terminal output. systemd/detached logs contain readable milestone lines instead of ANSI noise.
- Friendly codes such as `ANX-CDN429`, `ANX-SOURCE`, `ANX-DISK`, `ANX-ACCESS` and `ANX-SIZE` appear in the terminal. Detailed tracebacks go to rotating `logs/bot.log`; episode subprocess details go to `logs/episode-MAL-LANGUAGE-EPISODE.log`.

Logs and history are private. Detailed media logs may contain temporary signed source URLs; redact before sharing.

## Faster, with bounded recovery

### Speed improvements

The previous fixed two-second request gap was expensive. This version starts at **0.25 seconds between native requests**, still with one fragment worker. That is eight times less *artificial spacing*, **not a guarantee of eight times faster downloads**. Network throughput and provider policy still dominate.

On a 429, ANIMAX slows future requests to at least two seconds, waits, and retries the same episode. Repeated limits increase pacing; successful complete deliveries gradually relax it toward the configured baseline. It never rotates IPs or skips ahead through episodes to get around a limit.

Chromium resolves manifests without downloading video fragments in parallel with yt-dlp. Ordinary MP4 preparation copies the streams rather than re-encoding. Verified local episode files are reused after an interrupted upload instead of downloaded again. Native HLS partial fragments can resume when the source/format fingerprint matches; changed fingerprints restart the transfer to avoid mixing different content.

### Recovery paths actually implemented

1. Local title overrides → AniList → Jikan → the previously recorded title in `anime.json`.
2. Fresh browser/source resolution on bounded download retries, including recovery from a crashed player process.
3. Best available stream fallback when the preferred resolution is unavailable.
4. Safe native partial-download resume and verified completed-video cache reuse.
5. Fast MP4 remux → local H.264/AAC compatibility encoding if remux fails.
6. Subtitle burning → selectable soft-subtitle fallback if enabled, with an explicit warning. Discord may not display soft subtitles.
7. Oversized whole video → bounded bitrate-controlled compression attempts. The final size and duration are checked before upload; no splitting or truncation.
8. CDN cooldown persistence, Discord gateway reconnection, and durable interrupted-job resume.
9. systemd management, with detached-session operation when systemd is unavailable.

There is no promise of alternate servers for content the provider does not supply. Access denials and persistent rate limits stop safely, not through repeated uncontrolled fallbacks.

### HTTP 429 behavior

The first 429 stops further downloader requests immediately. `Retry-After` is honored when supplied. Otherwise the default waits are 300 seconds, then 600 seconds. After the configured retries, the job stops and a further cooldown remains saved. **No later episodes are requested while rate-limited.** `.status` and `.cancel` still work.

Do not run several downloaders against the same CDN/IP. Deleting `cdn_cooldown.json` or rapidly restarting is not a reliable fix for a server-side limit.

## `anime.json`: anime, episodes and message IDs

The app creates `anime.json` when needed; `anime.example.json` shows the empty starting structure. The journal records **episodes requested through this app**, not an invented catalogue of every anime on the internet.

The journal is grouped by MAL ID → language → episode → account/destination delivery. It records:

- Anime title and each requested episode's pending/downloading/uploading/uploaded/failed state.
- Account/channel IDs, accepted message IDs, message links, timestamps, attempts, video size and duration.
- A list of successful message records, including multiple intentional `force` sends.
- Last error code/log location and durable job records for restart/resume.

The message ID is committed only after Discord accepts the attachment. Writes are atomic and a previous-file backup is kept as `anime.json.bak`. A failed forced resend does not erase evidence of an earlier successful delivery.

**Exactly-once delivery is not guaranteed:** a crash between Discord accepting a message and the local journal commit can cause a duplicate on retry. Deleted messages are not automatically detected; use `force` if you want to resend them.

Keep `anime.json`, its backup, `.env`, title overrides and cooldown files when upgrading. This ZIP does not include a replacement `anime.json`. Do not manually replace real history with `anime.example.json`.

## Automatic dependencies

`python3 bot.py` creates/uses this project's `.venv`, installs missing pip packages from `requirements.txt`, fixes conflicting Discord packages in that private environment, and downloads Chromium binaries when missing. It re-executes using the virtual-environment interpreter, avoiding global/interpreter package mismatches.

```bash
python3 bot.py --setup   # Dependency setup only; no Discord login.
python3 bot.py --repair  # Explicit dependency/browser repair; no Discord login.
```

OS libraries and FFmpeg are **not pip packages**. On Ubuntu/Debian, `bash install.sh` handles those with apt. On another distribution, install FFmpeg/ffprobe and Playwright's Chromium OS dependencies using the appropriate package manager. Python bootstrap cannot fix an unavailable package index, missing sudo rights or a broken OS installation.

## Configuration

See `.env.example`; restart after changes.

| Setting | Default | Meaning |
|---|---:|---|
| `UPLOAD_LIMIT_MB` | `1000` | Whole-video cap in decimal MB; actual Discord entitlement still applies |
| `AUTO_COMPRESS` | `true` | Re-encode oversized videos to try fitting the cap; quality loss and CPU cost are possible |
| `QUALITY` | `720` | Preferred stream height; may fall back to a larger available stream |
| `SUBTITLE_MODE` | `burn` | `burn`, `mux`, or `none` |
| `SUBTITLE_FALLBACK` | `true` | Permit soft subtitles if burning fails; warn clearly |
| `REQUEST_INTERVAL` | `0.25` | Initial minimum spacing between native downloader requests |
| `RATE_LIMIT_COOLDOWN` | `300` | Initial 429 wait in seconds, honoring a longer Retry-After |
| `RATE_LIMIT_RETRIES` | `2` | Same-episode retries after cooldown |
| `EPISODE_ATTEMPTS` | `3` | Bounded non-429 resolve/download attempts |
| `MAX_CONSECUTIVE_FAILURES` | `3` | Stop after repeated non-429 episode failures |
| `STATUS_INTERVAL` | `8` | Seconds between Discord progress-message edits |
| `UPLOAD_DELAY` | `2` | Minimum delay between Discord episode uploads; slowmode can increase it |
| `AUTO_RESUME` | `true` | Resume queued/running/interrupted jobs after process restart for the same account |
| `KEEP_DOWNLOADS` | `false` | Keep successfully uploaded files instead of cleaning their working directory |
| `MAX_TEMP_GIB` | `8` | Per-episode temporary workspace budget, including intermediate copies |
| `OPERATION_TIMEOUT` | `3600` | Timeout per download/encode operation |
| `RESOLVE_TIMEOUT` | `60` | Seconds to resolve a source |
| `MAX_EPISODES` | `1000` | Maximum inclusive range per command |

Burning subtitles is CPU-intensive. It scales down to the preferred height when needed. `SUBTITLE_MODE=mux` is much faster, but Discord's player often does not display selectable subtitles; use a supporting player after downloading the file. `none` omits external captions. Missing caption tracks are reported, not translated or fabricated.

Successful workspaces are removed by default. Incomplete/cancelled/failed workspaces are retained for recovery, so monitor disk usage and delete no-longer-needed directories under `downloads/` **while the bot is stopped**. The disk guard stops work before running the filesystem completely full. `anime.json` is independent of that media cache.

## Diagnostics and validation

```bash
.venv/bin/python doctor.py
# Only when no CDN cooldown is active:
.venv/bin/python doctor.py --source 21 dub 1
```

The second check tests browser resolution and downloader **manifest** access. A successful manifest request does not prove that every video fragment or Discord upload will succeed. Reports are saved in `logs/doctor-report.json`; source URLs are redacted in that report.

30 local checks passed for this debug release, including mocked cloud uploads, deletion order, failed-upload retention, uncertain confirmation and journal-write failures. This package was validated with synthetic HLS/MP4 downloads, real FFmpeg conversion/compression, progress reporting, simulated HTTP 429 responses, journal/resume checks, single-instance locking and a detached dummy process. A live MAL 21 / episode 1 / dub manifest check passed from the build environment. The generated systemd unit passed `systemd-analyze verify`.

No Discord account login or real upload was performed for this release. Cloud attachment and message lifecycles were tested with mocked Discord responses, not a real account. A real host reboot/SSH logout and systemd service installation were not exercised in the build sandbox. Python execution checks used 3.13/Linux. **Test sources, test reports, caches, browsers, credentials and logs are deliberately excluded from the ZIP.**
