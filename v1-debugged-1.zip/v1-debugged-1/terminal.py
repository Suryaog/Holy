"""Human-facing terminal output; detailed traces stay in rotating private logs."""
from __future__ import annotations
import logging
import sys
import time
from pathlib import Path
from logging.handlers import RotatingFileHandler
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, BarColumn, TextColumn, TimeElapsedColumn
from rich.text import Text

ART = r'''
    _    _   _ ___ __  __    _    __  __
   / \  | \ | |_ _|  \/  |  / \   \ \/ /
  / _ \ |  \| || || |\/| | / _ \   >  <
 / ___ \| |\  || || |  | |/ ___ \ / /\ \
/_/   \_\_| \_|___|_|  |_/_/   \_\_/  \_\
'''


def nice_error(exc):
    text = str(exc).lower()
    status = getattr(exc, 'status', None)
    if type(exc).__name__ in {'UploadFailure','JournalCommitFailure'}:
        return ('ANX-UPLOAD-REVIEW' if getattr(exc,'outcome_unknown',False) else 'ANX-UPLOAD'), str(exc)
    if 'another animax instance' in text:
        return 'ANX-RUNNING', 'Another ANIMAX instance holds the lock. Stop the existing service/detached/foreground process first.'
    if 'missing from' in text or 'ffmpeg' in text and 'missing' in text:
        return 'ANX-SETUP', 'A runtime dependency is missing. Run bash install.sh; Python packages can also be repaired with python3 bot.py --repair.'
    if 'permission denied' in text:
        return 'ANX-FILES', 'The process cannot access a required file. Check project ownership and directory permissions.'
    if 'must be' in text or 'invalid anime.json' in text:
        return 'ANX-CONFIG', 'A configuration or history file is invalid. The precise field is in logs/bot.log; history was not erased.'
    if status == 429 and type(exc).__module__.startswith('discord'):
        return 'ANX-DISCORD429', 'Discord rate-limited the upload. The job stopped safely; wait before resuming.'
    if '429' in text or status == 429:
        return 'ANX-CDN429', 'The video server asked us to slow down. Cooldown saved; no episode hopping.'
    if '403' in text or status == 403:
        return 'ANX-ACCESS', 'Access was refused. Check source availability or channel permissions; repeated retries will not grant access.'
    if status == 413 or 'whole episode is' in text:
        return 'ANX-SIZE', 'The whole video exceeds the allowed upload size. Compression may help; splitting is disabled.'
    if 'disk' in text or 'storage' in text or 'space' in text:
        return 'ANX-DISK', 'Not enough temporary disk space. Free disk space or increase the configured storage budget.'
    if 'timed out' in text or 'timeout' in text or 'connection' in text:
        return 'ANX-NET', 'The connection stalled. A bounded retry may recover it; check your server network if it persists.'
    if 'libnspr' in text or 'shared libraries' in text or 'browsertype.launch' in text:
        return 'ANX-BROWSER', 'Chromium cannot start. Run bash install.sh to install its Linux dependencies.'
    if 'subtitle' in text:
        return 'ANX-SUBTITLE', 'Subtitle processing failed. See the episode log; a soft-subtitle fallback may be available.'
    if 'no playable' in text or 'unmapped' in text or '404' in text:
        return 'ANX-SOURCE', 'This episode/language could not be resolved. It may be missing, unmapped or unavailable.'
    if 'token' in text or 'login' in text:
        return 'ANX-LOGIN', 'Login failed. Check the token locally in .env; never post it in chat.'
    return 'ANX-MEDIA', 'This operation failed. The detailed reason is saved in the local logs; the job will not silently mark it complete.'


class Terminal:
    def __init__(self, quiet=False):
        self.console = Console(markup=False, quiet=quiet)
        self.tty = self.console.is_terminal and not quiet
        self.progress = Progress(TextColumn('{task.description}', markup=False), BarColumn(),
                                 TextColumn('{task.fields[label]}', markup=False), TimeElapsedColumn(),
                                 console=self.console, transient=False, disable=not self.tty)
        self.task = None
        self.last_stage = None
        self.last_bucket = -1

    def banner(self):
        self.console.print(Panel(Text(ART + '\n    V1-DEBUGGED-1  /  WHOLE EPISODES · SMART RETRIES · RESUME', style='bold cyan'),
                                 title='ANIMAX', subtitle='Type .help in Discord · Ctrl+C saves an interrupted job'))

    def event(self, message, style='cyan'):
        self.console.print(Text(f'[{time.strftime("%H:%M:%S")}] {message}', style=style))

    def start(self, title):
        self.finish()
        self.progress.start()
        self.task = self.progress.add_task(title, total=100, label='Resolving')
        self.last_stage = None; self.last_bucket = -1

    def update(self, job):
        fraction = job.progress.get('fraction')
        percent = min(100, max(0, fraction * 100)) if isinstance(fraction, (int, float)) else None
        label = f'{percent:5.1f}%' if percent is not None else job.phase
        speed = job.progress.get('speed') or 0
        if speed:
            label += f' · {speed / 1024**2:.2f} MiB/s'
        label += f' · {job.phase}' if percent is not None else ''
        if self.task is not None:
            self.progress.update(self.task, description=f'EP {job.current} · {job.title[:32]}',
                                 completed=percent or 0, label=label)
        if not self.tty:
            bucket = int((percent or 0)//10)
            if job.phase != self.last_stage or bucket > self.last_bucket:
                self.event(f'{job.title} / EP {job.current} / {label}')
                self.last_stage, self.last_bucket = job.phase, bucket

    def error(self, exc, log_name='logs/bot.log'):
        code, message = nice_error(exc)
        self.event(f'{code} · {message}', 'bold red')
        self.event(f'Details → {log_name}', 'dim')

    def finish(self):
        if self.task is not None:
            self.progress.remove_task(self.task)
        self.task = None
        self.progress.stop()


def setup_logging(root: Path):
    logs = root/'logs'; logs.mkdir(exist_ok=True)
    handler = RotatingFileHandler(logs/'bot.log', maxBytes=5*1024**2, backupCount=4)
    handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s'))
    logging.basicConfig(level=logging.INFO, handlers=[handler], force=True)
    logging.getLogger('aiohttp.access').setLevel(logging.WARNING)
    logging.getLogger('discord').setLevel(logging.WARNING)
    (logs/'bot.log').chmod(0o600)
