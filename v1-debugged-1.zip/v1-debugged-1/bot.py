from __future__ import annotations

# This entry point bootstraps missing Python packages before third-party imports.
if __name__ == '__main__':
    from bootstrap import ensure_runtime
    ensure_runtime()

import asyncio
import contextlib
from dataclasses import dataclass, field
import json
import logging
import math
import os
from pathlib import Path
import shutil
import signal
import sys
import time
import uuid

import discord
from discord.ext import commands
from dotenv import load_dotenv

from diagnostics import dependency_report
from media import MediaError, UploadTooLarge, cached_video, check_upload_size, download, fit_whole_video, probe
from metadata import TitleError, clean_title, episode_caption, fetch_anime_title
from rate_limits import Cooldown, RateLimitError, cooldown_seconds
from resolver import Resolver
from storage import Library
from terminal import Terminal, nice_error, setup_logging
from upload import upload_episode, UploadFailure, JournalCommitFailure, write_report

ROOT = Path(__file__).resolve().parent
log = logging.getLogger('animax')


def number(name, default, low, high, kind=int):
    value = kind(os.getenv(name, str(default)))
    if not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f'{name} must be between {low} and {high}.')
    return value


def enabled(name, default=True):
    return os.getenv(name, str(default)).lower() not in {'0','false','no','off'}


@dataclass
class Settings:
    channel_id: int = 0
    upload_mb: int = 1000
    quality: int = 720
    subtitle_mode: str = 'burn'
    max_episodes: int = 1000
    max_temp_bytes: int = 8 * 1024**3
    operation_timeout: int = 3600
    resolve_timeout: int = 60
    delay: int = 2
    attempts: int = 3
    max_consecutive_failures: int = 3
    headless: bool = True
    request_interval: float = 0.25
    rate_limit_cooldown: int = 300
    rate_limit_retries: int = 2
    status_interval: int = 8
    auto_resume: bool = True
    auto_compress: bool = True
    subtitle_fallback: bool = True
    keep_downloads: bool = False
    upload_timeout: int = 1800
    upload_mode: str = "auto"
    prepare_timeout: int = 300
    delete_trigger: bool = True

    @classmethod
    def from_env(cls):
        mode = os.getenv('SUBTITLE_MODE','burn').lower()
        if mode not in {'burn','mux','none'}:
            raise ValueError('SUBTITLE_MODE must be burn, mux or none.')
        upload_mode = os.getenv('UPLOAD_MODE','auto').lower()
        if upload_mode not in {'auto','cloud','multipart'}: raise ValueError('UPLOAD_MODE must be auto, cloud or multipart.')
        return cls(upload_mode=upload_mode, upload_timeout=number('UPLOAD_TIMEOUT',1800,30,14400),
            prepare_timeout=number('PREPARE_TIMEOUT',300,30,3600), delete_trigger=enabled('DELETE_DOWNLOAD_TRIGGER'), channel_id=number('CHANNEL_ID',0,0,2**64-1), upload_mb=number('UPLOAD_LIMIT_MB',1000,1,2000),
            quality=number('QUALITY',720,144,2160), subtitle_mode=mode,
            max_episodes=number('MAX_EPISODES',1000,1,10000), max_temp_bytes=number('MAX_TEMP_GIB',8,1,1000)*1024**3,
            operation_timeout=number('OPERATION_TIMEOUT',3600,60,86400), resolve_timeout=number('RESOLVE_TIMEOUT',60,10,300),
            delay=number('UPLOAD_DELAY',2,1,300), attempts=number('EPISODE_ATTEMPTS',3,1,5),
            max_consecutive_failures=number('MAX_CONSECUTIVE_FAILURES',3,1,100),
            request_interval=number('REQUEST_INTERVAL',0.25,0.1,10,float),
            rate_limit_cooldown=number('RATE_LIMIT_COOLDOWN',300,60,3600), rate_limit_retries=number('RATE_LIMIT_RETRIES',2,0,5),
            status_interval=number('STATUS_INTERVAL',8,5,120), auto_resume=enabled('AUTO_RESUME'),
            auto_compress=enabled('AUTO_COMPRESS'), subtitle_fallback=enabled('SUBTITLE_FALLBACK'),
            keep_downloads=enabled('KEEP_DOWNLOADS',False), headless=enabled('HEADLESS'))


def validate_request(mal, language, start, end, maximum):
    if mal < 1 or start < 1 or end < start or end-start+1 > maximum:
        raise commands.BadArgument(f'Use positive MAL/episode numbers and an inclusive range of at most {maximum} episodes.')
    if language not in {'dub','sub'}:
        raise commands.BadArgument('Choose dub or sub.')


@dataclass
class Job:
    mal: int
    language: str
    start: int
    end: int
    channel_id: int
    title: str = ''
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    current: int = 0
    phase: str = 'Queued'
    sent: int = 0
    skipped: int = 0
    failed: int = 0
    cooldown_until: float = 0
    progress: dict = field(default_factory=dict)
    error: str = ""
    notice: str = ""
    stage_started: float = field(default_factory=time.monotonic)

    def text(self):
        fraction = self.progress.get('fraction')
        if isinstance(fraction, (int, float)):
            value = max(0,min(1,fraction)); blocks = int(value*20)
            bar = '█'*blocks + '░'*(20-blocks)
            estimate = '~' if self.progress.get('estimated') and value < 1 else ''
            progress = f'{bar} {estimate}{value*100:.1f}% downloaded'
        else:
            progress = '░'*20 + ' waiting for download size'
        speed = self.progress.get('speed') or 0
        eta = self.progress.get('eta')
        if speed: progress += f' · {speed/1024**2:.2f} MiB/s'
        if eta is not None: progress += f' · ETA {int(eta)}s'
        remaining = max(0,math.ceil(self.cooldown_until-time.time()))
        pause = f' · cooldown {remaining}s' if remaining else ''
        title = self.title.replace('`', "'") or f'MAL {self.mal}'
        return (f'**ANIMAX · {title}**\nEpisode {self.current or self.start} / range {self.start}–{self.end} · {self.language.upper()}\n'
                f'`{progress}`\n{self.phase}{pause}\nSent {self.sent} · Already sent {self.skipped} · Failed {self.failed} · <#{self.channel_id}>')


    def episode_text(self):
        title = discord.utils.escape_markdown(self.title or f'MAL {self.mal}')
        fraction = self.progress.get('fraction')
        if isinstance(fraction, (int,float)) and math.isfinite(fraction):
            value = min(1,max(0,fraction))
            percent = 100 if value >= 1 else min(99,int(value*100))
            filled = int(value*20)
            percentage = f'{percent}%'
            estimate = ' (estimated)' if self.progress.get('estimated') and value < 1 else ''
        else:
            filled = 0
            percentage = '0%' if self.phase in {'Queued','Resolving','Preparing'} else '—%'
            estimate = ''
        phase = self.phase
        if phase.startswith('Resolving'): phase = 'Resolving'
        if phase.startswith('Uploading'): phase = 'Uploading'
        if phase.startswith('Using verified'): phase = 'Preparing upload'
        if phase.startswith('Fitting'): phase = 'Compressing'
        if phase.startswith('CDN cooldown'): phase = 'Waiting for CDN cooldown'
        content = (f'**{title}**\n\nEpisode : `{self.current or self.start}/{self.end}`\n\n'
                   f'Download Status : `{phase.replace("`", "")}`\n\n'
                   f'`{"█"*filled}{"░"*(20-filled)}` **{percentage}**{estimate}')
        if self.cooldown_until > time.time():
            content += f'\nCooldown : `{math.ceil(self.cooldown_until-time.time())}s`'
        if phase in {'Preparing MP4','Compatibility encoding','Burning subtitles','Muxing subtitles','Uploading','Posting message','Checking video','Compressing'}:
            elapsed = int(time.monotonic()-self.stage_started)
            if elapsed >= 5: content += f'\nStage elapsed : `{elapsed//60}m {elapsed%60}s`'
        if self.notice: content += '\n\n' + self.notice[:400]
        if self.error: content += '\n\n' + self.error[:900]
        return content


class MegaPlayBot(commands.Bot):
    def __init__(self, settings: Settings, library: Library, ui=None):
        super().__init__(command_prefix='.', strip_after_prefix=True, self_bot=True, help_command=None, allowed_mentions=discord.AllowedMentions.none())
        self.cfg, self.library, self.ui = settings, library, ui or Terminal(quiet=True)
        self.cdn_cooldown = Cooldown(ROOT/'cdn_cooldown.json')
        self.job = self.worker = None
        self.shutting_down = False
        self.startup_done = False

        @self.command(name='download', ignore_extra=False)
        async def download_entry(ctx, mal_id: int, language: str, start: int, end: int, mode: str='resume'):
            await self.download_command(ctx,mal_id,language,start,end,mode)
        @self.command(name='status', ignore_extra=False)
        async def status_entry(ctx):
            await ctx.send(self.job.episode_text() if self.job else 'ANIMAX is ready. No active job.')
        @self.command(name='cancel', ignore_extra=False)
        async def cancel_entry(ctx):
            if self.worker and not self.worker.done():
                self.worker.cancel()
                await ctx.send('Cancellation requested. Uploaded episodes and CDN cooldowns are preserved.')
            else: await ctx.send('No active job to cancel.')
        @self.command(name='help', aliases=['mphelp'], ignore_extra=False)
        async def help_entry(ctx):
            await ctx.send('**ANIMAX v1-debugged-1**\n`.download 21 dub 1 100`\n`.download 21 sub 1 100 force` — resend\n'
                           '`.status` · `.cancel` · `.resume` / `.retry` · `.history 21`\n'
                           'One whole MP4 per message. Each episode has its own temporary progress message, deleted after a confirmed upload. Only your own commands are accepted.')
        @self.command(name='history', ignore_extra=False)
        async def history_entry(ctx, mal_id: int):
            await ctx.send(self.library.summary(mal_id))
        @self.command(name='resume', aliases=['retry'], ignore_extra=False)
        async def resume_entry(ctx):
            if self.worker and not self.worker.done():
                await ctx.send('A job is already active. Use .status or .cancel.'); return
            record = self.library.latest_job(self.user.id)
            if not record: await ctx.send('No saved job for this account.'); return
            await self.resume_record(record, ctx)

    async def on_ready(self):
        self.ui.event(f'Connected as {self.user}. Commands: .download · .status · .help', 'bold green')
        if not self.startup_done:
            self.startup_done = True
            if self.cfg.auto_resume:
                record = self.library.latest_job(self.user.id, active_only=True)
                if record:
                    try: await self.resume_record(record)
                    except Exception as exc:
                        log.exception('Automatic resume failed')
                        self.ui.error(exc)

    async def on_message(self, message):
        if self.user and message.author.id == self.user.id:
            await self.process_commands(message)

    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound): return
        if isinstance(error, commands.UserInputError):
            await ctx.send(f'{error}\nUsage: `.download MAL_ID dub|sub START END [resume|force]`')
        else:
            log.error('Command failed', exc_info=(type(error),error,error.__traceback__))
            code,text = nice_error(error)
            self.ui.error(error)
            await ctx.send(f'{code}: {text} Details: logs/bot.log')

    async def channel_for(self, channel_id):
        channel = self.get_channel(int(channel_id)) or await self.fetch_channel(int(channel_id))
        if not hasattr(channel,'send'): raise commands.BadArgument('Destination does not support messages.')
        return channel

    def check_permissions(self, target):
        guild = getattr(target,'guild',None)
        if guild and guild.me:
            permissions = target.permissions_for(guild.me)
            send = permissions.send_messages_in_threads if isinstance(target,discord.Thread) else permissions.send_messages
            if not (permissions.view_channel and send and permissions.attach_files):
                raise commands.BadArgument('The account needs View Channel, Send Messages and Attach Files in the destination.')

    async def resume_record(self, record, ctx=None):
        target = await self.channel_for(record['channel_id'])
        self.check_permissions(target)
        if ctx is None:
            origin = await self.channel_for(record.get('command_channel_id',record['channel_id']))
            class Context:
                channel = origin
                async def send(self, content): return await origin.send(content)
            ctx = Context()
        job = Job(int(record['mal']), record['language'], int(record['start']), int(record['end']), target.id,
                  title=record.get('title',''), id=record['id'])
        await self.launch_job(ctx,target,job,False)

    async def download_command(self, ctx, mal_id: int, language: str, start: int, end: int, mode='resume'):
        language = language.lower()
        validate_request(mal_id,language,start,end,self.cfg.max_episodes)
        if mode.lower() not in {'resume','force'}: raise commands.BadArgument('Mode must be resume or force.')
        if self.worker and not self.worker.done():
            await ctx.send('One job is already running. Use .status or .cancel.'); return
        target = await self.channel_for(self.cfg.channel_id) if self.cfg.channel_id else ctx.channel
        self.check_permissions(target)
        started = await self.launch_job(ctx,target,Job(mal_id,language,start,end,target.id),mode.lower()=='force')
        if started and self.cfg.delete_trigger:
            trigger = getattr(ctx,'message',None)
            if trigger is not None:
                await self.safe_delete(trigger,'download trigger')

    async def launch_job(self, ctx, target, job, force):
        if self.worker and not self.worker.done():
            await ctx.send('Another job is active.'); return False
        self.job = job
        self.library.job(job.id, account_id=str(self.user.id), channel_id=str(target.id),
                         command_channel_id=str(ctx.channel.id), mal=job.mal, language=job.language,
                         start=job.start,end=job.end,title=job.title,status='queued')
        self.worker = asyncio.create_task(self.run_job(ctx,target,job,self.cfg.upload_mb*1_000_000,force))
        return True

    async def report_loop(self, message, job):
        previous = ''
        while True:
            await asyncio.sleep(self.cfg.status_interval)
            self.ui.update(job)
            text = job.episode_text()
            if text != previous:
                try: await message.edit(content=text)
                except discord.NotFound: return
                except discord.HTTPException: log.warning('Status-message edit failed',exc_info=True)
                previous = text

    async def safe_delete(self, message, label):
        # Only delete messages authored by the logged-in account.
        author = getattr(message,'author',None)
        if author is None or self.user is None or author.id != self.user.id:
            log.warning('Refused to delete %s: message ownership was not verified',label)
            return False
        try:
            await asyncio.wait_for(message.delete(),timeout=20)
            return True
        except discord.NotFound:
            return True
        except Exception:
            log.warning('Could not delete %s; upload result is not changed',label,exc_info=True)
            self.ui.event(f'ANX-CLEANUP · Could not delete {label}. Details in logs/bot.log.','yellow')
            return False

    async def edit_status(self, message, job):
        if not message: return False
        try:
            await asyncio.wait_for(message.edit(content=job.episode_text()),timeout=20)
            return True
        except Exception:
            log.warning('Could not update episode progress message',exc_info=True)
            return False

    async def stop_reporter(self, reporter):
        if reporter:
            reporter.cancel()
            with contextlib.suppress(asyncio.CancelledError): await reporter

    def delivery(self, job, target):
        try:
            return self.library.data['anime'][str(job.mal)]['episodes'][job.language][str(job.current)]['deliveries'][f'{self.user.id}:{target.id}']
        except KeyError: return {}

    async def new_progress(self, ctx, job, target):
        message = await ctx.send(job.episode_text())
        references = list(self.delivery(job,target).get('progress_messages',[]))
        if getattr(message,'id',None):
            references.append({'channel_id':str(ctx.channel.id),'message_id':str(message.id)})
        self.record_episode(job,target,'preparing',progress_messages=references)
        return message

    async def clear_progress(self, job, target, current, ctx):
        pending = []
        references = self.delivery(job,target).get('progress_messages',[])
        for reference in references:
            try:
                if current and str(getattr(current,'id','')) == reference['message_id'] and str(ctx.channel.id) == reference['channel_id']:
                    message = current
                else:
                    channel = await self.channel_for(reference['channel_id'])
                    message = await channel.fetch_message(int(reference['message_id']))
                if not await self.safe_delete(message,'episode progress message'): pending.append(reference)
            except discord.NotFound: pass
            except Exception:
                log.warning('Progress cleanup failed after successful upload',exc_info=True)
                pending.append(reference)
        # The accepted video message ID was committed before reaching this method.
        self.record_episode(job,target,'uploaded',progress_messages=pending)

    def phase(self, job, text):
        if job.phase != text:
            log.info('EPISODE_STAGE job=%s mal=%s language=%s episode=%s stage=%s',job.id,job.mal,job.language,job.current,text)
            job.stage_started = time.monotonic()
        job.phase = text
        self.ui.update(job)

    async def wait_for_cdn(self, ctx, job):
        if self.cdn_cooldown.remaining() <= 0: return
        job.cooldown_until = self.cdn_cooldown.until
        self.phase(job,'CDN cooldown — no requests')
        self.ui.event(f'ANX-CDN429 · Waiting {math.ceil(self.cdn_cooldown.remaining())}s. This pause survives restarts.', 'yellow')
        while self.cdn_cooldown.remaining() > 0:
            await asyncio.sleep(min(30,self.cdn_cooldown.remaining()))
        job.cooldown_until = 0

    def record_episode(self, job, target, status, **kwargs):
        self.library.record(job.mal,job.title,job.language,job.current,self.user.id,target.id,status,**kwargs)

    def preserve_log(self, work, job):
        source = work/'process.log'
        destination = ROOT/'logs'/f'episode-{job.mal}-{job.language}-{job.current}.log'
        destination.parent.mkdir(exist_ok=True)
        if source.exists():
            # Bound retained subprocess logs; the latest 2 MiB contain the recent error.
            with source.open('rb') as file:
                file.seek(max(0,source.stat().st_size-2*1024**2))
                destination.write_bytes(file.read())
            destination.chmod(0o600)
        return str(destination.relative_to(ROOT)) if source.exists() else 'logs/bot.log'

    async def run_job(self, ctx, target, job, limit, force):
        cfg = self.cfg
        reporter = None; message = None; status = 'failed'; work = None
        consecutive = 0
        try:
            self.library.job(job.id,status='running')
            cached_title = self.library.data['anime'].get(str(job.mal),{}).get('title')
            try: job.title = await fetch_anime_title(job.mal,ROOT/'title_overrides.json')
            except TitleError:
                if cached_title and not cached_title.startswith('MAL '): job.title = clean_title(cached_title)
                else: raise
            self.library.job(job.id,title=job.title)
            for ep in range(job.start,job.end+1):
                if not self.library.completed(job.mal,job.language,ep,self.user.id,target.id):
                    self.library.record(job.mal,job.title,job.language,ep,self.user.id,target.id,'pending',save=False)
            self.library.save()
            self.ui.start(job.title)
            for episode in range(job.start,job.end+1):
                job.current = episode; job.progress = {'fraction':0}; job.error = ''; job.notice = ''
                if not force and self.library.completed(job.mal,job.language,episode,self.user.id,target.id):
                    # Recover cleanup after a crash between the accepted-ID commit and deletion.
                    if self.delivery(job,target).get('progress_messages'):
                        try: await self.clear_progress(job,target,None,ctx)
                        except Exception: log.warning('Deferred progress cleanup failed',exc_info=True)
                    job.skipped += 1; continue
                work = ROOT/'downloads'/f'{self.user.id}-{target.id}-{job.mal}-{job.language}-{episode}'
                work.mkdir(parents=True,exist_ok=True,mode=0o700)
                upload_report = ROOT/'logs'/f'upload-{job.mal}-{job.language}-{episode}.json'
                delivered = False; upload_started = False
                message = None; reporter = None
                previous = dict(self.delivery(job,target))
                try:
                    self.phase(job,'Preparing')
                    message = await self.new_progress(ctx,job,target)
                    reporter = asyncio.create_task(self.report_loop(message,job))
                    if previous.get('needs_review') and not force:
                        raise UploadFailure('The previous send has an uncertain outcome. Check the destination first. Use a force download only if you intentionally want to resend.',stage='review',outcome_unknown=True)
                    cached = await cached_video(work,job.language,cfg.quality,cfg.subtitle_mode,cfg.subtitle_fallback)
                    source,note = cached if cached else (None,None)
                    if cached:
                        job.progress = {'fraction':1,'estimated':False}
                        self.phase(job,'Using verified local episode')
                    attempt = 0; rate_hits = 0
                    while source is None:
                        await self.wait_for_cdn(ctx,job)
                        self.phase(job,f'Resolving · attempt {attempt+1}/{cfg.attempts}')
                        self.record_episode(job,target,'downloading')
                        try:
                            async with Resolver(cfg.resolve_timeout,cfg.headless) as resolver:
                                async with resolver.resolve(job.mal,job.language,episode) as stream:
                                    self.phase(job,'Downloading')
                                    def progress(data):
                                        job.progress = data
                                        self.ui.update(job)
                                    source,note = await download(stream,work,job.language,quality=cfg.quality,
                                        subtitle_mode=cfg.subtitle_mode,max_bytes=cfg.max_temp_bytes,
                                        timeout=cfg.operation_timeout,prepare_timeout=cfg.prepare_timeout,
                                        request_interval=max(cfg.request_interval,self.cdn_cooldown.interval),
                                        on_progress=progress,on_phase=lambda value:self.phase(job,value),
                                        subtitle_fallback=cfg.subtitle_fallback)
                        except RateLimitError as exc:
                            rate_hits += 1
                            self.cdn_cooldown.slow_down(cfg.request_interval)
                            self.cdn_cooldown.defer(cooldown_seconds(rate_hits,cfg.rate_limit_cooldown,exc.retry_after))
                            job.cooldown_until = self.cdn_cooldown.until
                            self.preserve_log(work,job)
                            if rate_hits > cfg.rate_limit_retries: raise
                        except asyncio.CancelledError: raise
                        except Exception as exc:
                            attempt += 1
                            log.exception('Episode %s attempt %s failed',episode,attempt)
                            self.ui.error(exc,self.preserve_log(work,job))
                            if attempt >= cfg.attempts: raise
                            self.phase(job,f'Retrying same episode in {min(5*2**(attempt-1),30)}s')
                            await asyncio.sleep(min(5*2**(attempt-1),30))
                    job.progress['fraction'] = 1
                    if source.stat().st_size > limit and cfg.auto_compress:
                        self.phase(job,'Fitting whole video to upload cap')
                        source = await fit_whole_video(source,limit,timeout=cfg.operation_timeout,max_bytes=cfg.max_temp_bytes)
                        marker = work/'ready.json'
                        if marker.exists():
                            ready = json.loads(marker.read_text()); ready['file'] = source.name
                            temporary = marker.with_suffix('.tmp'); temporary.write_text(json.dumps(ready)); temporary.replace(marker)
                    self.phase(job,'Checking video')
                    check_upload_size(source,limit)
                    info = await probe(source)
                    log.info('VIDEO_READY mal=%s episode=%s bytes=%s duration=%s format=%s',job.mal,episode,
                             source.stat().st_size,info['format']['duration'],info['format'].get('format_name','unknown'))
                    if note:
                        job.notice = note
                        self.ui.event(note,'yellow')
                    self.check_permissions(target)
                    self.phase(job,'Uploading')
                    await self.edit_status(message,job)
                    self.record_episode(job,target,'uploading',subtitle_note=note)
                    upload_started = True
                    sent = await upload_episode(target,source,episode_caption(job.title,episode),
                        filename=f'MAL-{job.mal}_EP-{episode:04d}_{job.language}.mp4', report_path=upload_report,
                        timeout=cfg.upload_timeout,mode=cfg.upload_mode,on_phase=lambda value:self.phase(job,value))
                    try:
                        # This commit MUST precede progress-message deletion or cache cleanup.
                        self.record_episode(job,target,'uploaded',message_id=str(sent.id),message_ids=[str(sent.id)],
                            jump_url=getattr(sent,'jump_url',None),size_bytes=source.stat().st_size,
                            duration_seconds=float(info['format']['duration']),filename=source.name,needs_review=False)
                    except Exception as exc:
                        log.critical('UPLOAD ACCEPTED BUT JOURNAL FAILED: channel=%s message=%s',target.id,sent.id,exc_info=True)
                        raise JournalCommitFailure(f'Discord accepted message {sent.id}, but anime.json could not be saved. Do not resend blindly; repair the journal first.',stage='journal',outcome_unknown=True) from exc
                    delivered = True; upload_started = False
                    job.sent += 1; consecutive = 0
                    self.phase(job,'Uploaded')
                    await self.stop_reporter(reporter); reporter = None
                    await self.edit_status(message,job)
                    # Cleanup failures never reclassify an accepted/journaled video as failed.
                    try:
                        await self.clear_progress(job,target,message,ctx)
                    except Exception:
                        log.warning('Uploaded message %s is safe, but progress cleanup could not be saved',sent.id,exc_info=True)
                    message = None
                    try:
                        self.cdn_cooldown.relax(cfg.request_interval)
                        if not cfg.keep_downloads: shutil.rmtree(work)
                    except OSError:
                        log.warning('Post-upload housekeeping failed; the video remains uploaded',exc_info=True)
                    self.ui.event(f'EP {episode} delivered · message {sent.id}', 'bold green')
                    await asyncio.sleep(max(cfg.delay,getattr(target,'slowmode_delay',0)))
                except asyncio.CancelledError:
                    # A cancel during final message posting may leave an accepted message
                    # without a reply. Do not auto-resume such an episode after restart.
                    if upload_started and upload_report.exists():
                        with contextlib.suppress(OSError,ValueError):
                            if json.loads(upload_report.read_text()).get('outcome_unknown'):
                                self.record_episode(job,target,'needs_review',needs_review=True)
                                status = 'needs_review'
                    raise
                except Exception as exc:
                    log.exception('Episode %s stopped at %s',episode,job.phase)
                    code,text = nice_error(exc)
                    media_path = self.preserve_log(work,job)
                    path = str(upload_report.relative_to(ROOT)) if isinstance(exc,UploadFailure) else media_path
                    review = isinstance(exc,UploadFailure) and exc.outcome_unknown
                    if review: status = 'needs_review'
                    with contextlib.suppress(OSError):
                        self.record_episode(job,target,'needs_review' if review else 'failed',needs_review=review,
                            error={'code':code,'message':text,'log':path})
                    self.ui.error(exc,path)
                    job.failed += 1; consecutive += 1
                    self.phase(job,'Needs review' if review else 'Failed')
                    extra = ''
                    if isinstance(exc,UploadFailure):
                        extra = f' HTTP {exc.status} / Discord code {exc.code}.' if exc.status is not None else ''
                    job.error = f'{code}: {text}{extra}\nDetails : `{path}`'
                    if not await self.edit_status(message,job):
                        with contextlib.suppress(Exception): await ctx.send(job.episode_text())
                    if isinstance(exc,(RateLimitError,discord.HTTPException,UploadTooLarge,UploadFailure)) or consecutive >= cfg.max_consecutive_failures:
                        break
                finally:
                    await self.stop_reporter(reporter); reporter = None
                    if delivered: message = None
            else:
                status = 'finished' if job.failed == 0 else 'finished_with_errors'
                self.phase(job,'Finished' if not job.failed else 'Finished with missing episodes — use .retry')
        except asyncio.CancelledError:
            if status != 'needs_review':
                status = 'interrupted' if self.shutting_down else 'cancelled'
            self.phase(job,'Needs review' if status == 'needs_review' else 'Interrupted' if self.shutting_down else 'Cancelled')
            if message and not self.shutting_down: await self.edit_status(message,job)
        except Exception as exc:
            log.exception('Job stopped')
            self.ui.error(exc)
            self.phase(job,'Failed')
            code,text = nice_error(exc)
            job.error = f'{code}: {text}\nDetails : `logs/bot.log`'
            if message:
                await self.edit_status(message,job)
            else:
                with contextlib.suppress(Exception): await ctx.send(job.episode_text())
        finally:
            try:
                self.library.job(job.id,status=status,current=job.current,sent=job.sent,failed=job.failed,
                                 skipped=job.skipped,title=job.title)
            except OSError: log.critical('Could not persist final job state',exc_info=True)
            await self.stop_reporter(reporter)
            self.ui.finish()

    async def close(self):
        self.shutting_down = True
        if self.worker and not self.worker.done():
            self.worker.cancel()
            with contextlib.suppress(asyncio.CancelledError): await self.worker
        self.ui.finish()
        await super().close()


class InstanceLock:
    def __init__(self,path): self.path=path; self.file=None
    def __enter__(self):
        self.file=self.path.open('a+')
        try:
            if os.name=='posix':
                import fcntl
                fcntl.flock(self.file.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            else:
                import msvcrt
                self.file.seek(0); self.file.write(' '); self.file.flush(); self.file.seek(0)
                msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:
            self.file.close()
            raise RuntimeError('Another ANIMAX instance is already running. Stop it before starting another.') from None
        self.file.seek(0); self.file.truncate(); self.file.write(str(os.getpid())); self.file.flush()
        return self
    def __exit__(self,*args):
        if self.file: self.file.close()


async def run_client(bot,token):
    loop=asyncio.get_running_loop()
    for signum in (signal.SIGTERM,signal.SIGINT):
        with contextlib.suppress(NotImplementedError):
            loop.add_signal_handler(signum,lambda:asyncio.create_task(bot.close()))
    async with bot:
        await bot.start(token,reconnect=True)


def main():
    load_dotenv(ROOT/'.env')
    setup_logging(ROOT)
    ui=Terminal(); ui.banner()
    try:
        dependency_report()
        if '--setup' in sys.argv or '--repair' in sys.argv:
            ui.event('Python dependencies and FFmpeg are ready. Use doctor.py to check Chromium OS libraries.', 'green')
            return
        token=os.getenv('DISCORD_TOKEN','').strip()
        if not token or token=='YOUR_USER_TOKEN_HERE':
            raise ValueError('Set DISCORD_TOKEN locally in .env before starting. Do not share it.')
        cfg=Settings.from_env()
        with InstanceLock(ROOT/'.animax.lock'):
            library=Library(ROOT/'anime.json')
            bot=MegaPlayBot(cfg,library,ui)
            asyncio.run(run_client(bot,token))
    except (ValueError,discord.LoginFailure) as exc:
        log.exception('Configuration or login failed'); ui.error(exc); raise SystemExit(78)
    except KeyboardInterrupt: pass
    except Exception as exc:
        log.exception('Startup stopped'); ui.error(exc); raise SystemExit(1)


if __name__=='__main__': main()
