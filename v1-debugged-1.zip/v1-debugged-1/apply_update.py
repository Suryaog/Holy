#!/usr/bin/env python3
"""Back up and replace release code, never private settings/history/media.
Stop the bot/service first. Example:
  python3 v1-debugged-1/apply_update.py --target /Holy/animaxv1
"""
from __future__ import annotations
import argparse
import ast
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile
import uuid

ROOT = Path(__file__).resolve().parent
VERSION = 'v1-debugged-1'
FILES = ('bot.py','bootstrap.py','terminal.py','storage.py','resolver.py','media.py','metadata.py',
         'downloader.py','rate_limits.py','diagnostics.py','doctor.py','upload.py','service.py','migrate.py',
         'install.sh','requirements.txt','.env.example','.gitignore','anime.example.json',
         'title_overrides.example.json','README.md')


def install(target):
    target = target.expanduser().resolve()
    if target == ROOT: raise RuntimeError('This is already the extracted release directory. Use its install.sh, or specify the existing installation as --target.')
    if not (target/'bot.py').is_file(): raise RuntimeError('Target must be an existing installation containing bot.py.')
    payload = {}
    for name in FILES:
        source = ROOT/name
        if not source.is_file(): raise RuntimeError(f'Incomplete release: {name} is missing.')
        content = source.read_bytes()
        if name.endswith('.py'): ast.parse(content.decode('utf-8'),filename=name)
        destination = target/name
        if destination.is_symlink(): raise RuntimeError(f'Refusing to replace a symlink: {name}')
        payload[name] = content
    backup = target/'.release-backups'/f'{VERSION}-{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:6]}'
    backup.mkdir(parents=True,mode=0o700)
    existed = {}
    for name in FILES:
        destination = target/name
        existed[name] = destination.exists()
        if destination.exists(): shutil.copy2(destination,backup/name)
    replaced = []
    try:
        for name,content in payload.items():
            destination = target/name
            owner = destination.stat() if destination.exists() else target.stat()
            mode = stat.S_IMODE(destination.stat().st_mode) if destination.exists() else stat.S_IMODE((ROOT/name).stat().st_mode)
            descriptor,temporary = tempfile.mkstemp(prefix='.release-',dir=target)
            try:
                with os.fdopen(descriptor,'wb') as file:
                    file.write(content);file.flush();os.fsync(file.fileno())
                os.chmod(temporary,mode)
                if hasattr(os,'geteuid') and os.geteuid()==0:
                    os.chown(temporary,owner.st_uid,owner.st_gid)
                os.replace(temporary,destination)
                replaced.append(name)
            finally:
                if os.path.exists(temporary): os.unlink(temporary)
    except BaseException:
        for name in reversed(replaced):
            if existed[name]: shutil.copy2(backup/name,target/name)
            else: (target/name).unlink(missing_ok=True)
        raise
    (backup/'manifest.json').write_text(json.dumps({'version':VERSION,'files_existed':existed},indent=2))
    return backup


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target',type=Path,required=True)
    args=parser.parse_args()
    print('Stop the running bot/service before updating.')
    try: backup=install(args.target)
    except (RuntimeError,OSError,ValueError) as exc: raise SystemExit(f'Update failed: {exc}')
    print(f'Installed {VERSION}. Code backup: {backup}')
    print('Preserved: .env, anime.json, state.json, cooldowns, caches, logs, virtual environment and browser files.')
    print('Restart the existing service or run .venv/bin/python bot.py from the target directory.')
    print('Test one episode first: .download 21 dub 1 1')
    print('If upload still fails, inspect logs/upload-21-dub-1.json. Do not share .env.')


if __name__=='__main__': main()
