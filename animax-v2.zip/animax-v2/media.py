from __future__ import annotations

import asyncio
import contextlib
import json
import shutil
import sys
import os
import signal
import time
import logging
from pathlib import Path

from resolver import Stream, choose_caption
from diagnostics import error_hint, error_summary
from rate_limits import RateLimitError
log = logging.getLogger("animax.media")


class MediaError(RuntimeError):
    pass


class MediaProcessError(MediaError):
    def __init__(self, program: str, exit_code: int, output: str):
        self.exit_code = exit_code
        self.program = program
        self.summary = error_summary(output)
        self.hint = error_hint(output)
        super().__init__(f"{program} exited with code {exit_code}:\n{self.summary}\n{self.hint}")


def log_tail(path: Path, start: int = 0, count: int = 16000) -> str:
    with path.open("rb") as file:
        file.seek(max(start, path.stat().st_size - count))
        return file.read().decode("utf-8", "replace")


async def run_process(args: list[str], cwd: Path, *, timeout: float = 3600,
                      max_bytes: int = 8 * 1024**3, progress_file: Path | None = None, on_progress=None) -> str:
    """No shell. Kill/reap subprocesses on timeout, disk exhaustion or cancellation."""
    log = cwd / "process.log"
    start_offset = log.stat().st_size if log.exists() else 0
    started = time.monotonic()
    program = "yt-dlp" if len(args) > 2 and (args[1:3] == ["-m", "yt_dlp"] or Path(args[1]).name == "downloader.py") else Path(args[0]).name
    with log.open("ab") as output:
        log.chmod(0o600)
        output.write(f"\n=== ANIMAX PROCESS START: {program}; timeout={timeout}s ===\n".encode())
        output.flush()
        process = await asyncio.create_subprocess_exec(
            *args, cwd=str(cwd), stdout=output, stderr=asyncio.subprocess.STDOUT, start_new_session=(os.name != "nt"))
        waiter = asyncio.create_task(process.wait())
        deadline = asyncio.get_running_loop().time() + timeout
        try:
            while not waiter.done():
                if asyncio.get_running_loop().time() >= deadline:
                    raise MediaError("Media operation timed out.")
                usage = sum(p.stat().st_size for p in cwd.rglob("*") if p.is_file())
                if usage > max_bytes or shutil.disk_usage(cwd).free < 256 * 1024**2:
                    raise MediaError("Temporary-storage budget exceeded or disk nearly full.")
                if progress_file and on_progress and progress_file.exists():
                    try:
                        on_progress(json.loads(progress_file.read_text()))
                    except (ValueError, OSError):
                        pass
                await asyncio.wait({waiter}, timeout=0.5)
            if waiter.result() != 0:
                output.flush()
                program = "yt-dlp" if len(args) > 2 and (args[1:3] == ["-m", "yt_dlp"] or Path(args[1]).name == "downloader.py") else Path(args[0]).name
                raise MediaProcessError(program, waiter.result(), log_tail(log, start_offset))
        finally:
            if process.returncode is None:
                with contextlib.suppress(ProcessLookupError):
                    if os.name != "nt":
                        os.killpg(process.pid, signal.SIGTERM)
                    else:
                        process.terminate()
                try:
                    await asyncio.wait_for(asyncio.shield(waiter), 5)
                except asyncio.TimeoutError:
                    with contextlib.suppress(ProcessLookupError):
                        if os.name != "nt":
                            os.killpg(process.pid, signal.SIGKILL)
                        else:
                            process.kill()
                    await waiter
            if not waiter.done():
                await waiter
            output.write(f"\n=== ANIMAX PROCESS END: {program}; exit={process.returncode}; elapsed={time.monotonic()-started:.2f}s ===\n".encode())
            output.flush()
    if progress_file and on_progress and progress_file.exists():
        with contextlib.suppress(ValueError, OSError):
            on_progress(json.loads(progress_file.read_text()))
    # Read only a bounded tail, not an entire noisy subprocess log.
    return log_tail(log, start_offset)


async def probe(path: Path) -> dict:
    process = await asyncio.create_subprocess_exec(
        "ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", str(path),
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    try:
        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), 30)
        except asyncio.TimeoutError:
            raise MediaError(f"FFprobe timed out after 30 seconds while examining {path.name}.") from None
        if stderr:
            with (path.parent/'probe.log').open('ab') as details:
                details.write(b'\n'+path.name.encode()+b':\n'+stderr[-16000:])
            (path.parent/'probe.log').chmod(0o600)
        if process.returncode:
            raise MediaError(f"FFprobe could not read {path.name}: {error_summary(stderr.decode('utf-8','replace'))}")
        result = json.loads(stdout)
        if not any(s.get("codec_type") == "video" for s in result.get("streams", [])):
            raise MediaError("Download contains no video stream.")
        if float(result["format"].get("duration", 0)) <= 0:
            raise MediaError("Downloaded video has no valid duration.")
        log.info('PROBE_OK file=%s size=%s format=%s duration=%s streams=%s',path.name,path.stat().st_size,
                 result['format'].get('format_name'),result['format'].get('duration'),
                 [(stream.get('codec_type'),stream.get('codec_name')) for stream in result.get('streams',[])])
        return result
    finally:
        if process.returncode is None:
            with contextlib.suppress(ProcessLookupError):
                process.kill()
            await process.communicate()


async def write_cookie_file(stream: Stream, cookie_file: Path):
    lines = ["# Netscape HTTP Cookie File"]
    for cookie in await stream.context.cookies():
        lines.append("\t".join([cookie["domain"], str(cookie["domain"].startswith(".")).upper(),
                                cookie["path"], str(cookie["secure"]).upper(),
                                str(max(0, int(cookie.get("expires", 0)))),
                                cookie["name"], cookie["value"]]))
    cookie_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    cookie_file.chmod(0o600)


async def download(stream: Stream, work: Path, language: str, *, quality: int = 720,
                   subtitle_mode: str = "burn", max_bytes: int = 8 * 1024**3,
                   timeout: int = 3600, request_interval: float = 0.25, on_progress=None, on_phase=None, subtitle_fallback: bool = False, prepare_timeout: int = 300, encoder_preset: str = "ultrafast", upload_limit: int | None = None) -> tuple[Path, str | None]:
    work.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(work).free < 512 * 1024**2:
        raise MediaError("At least 512 MiB of free disk space is required.")
    cookie_file = work / "cookies.txt"
    await write_cookie_file(stream, cookie_file)
    rate_report = work / "rate-limit.json"
    progress_file = work / "progress.json"
    progress_file.unlink(missing_ok=True)
    args = [sys.executable, str(Path(__file__).with_name("downloader.py")),
            "--mp-request-interval", str(request_interval), "--mp-rate-limit-report", str(rate_report),
            "--mp-progress-file", str(progress_file),
            "--ignore-config", "--no-playlist", "--no-progress",
            "--no-warnings", "--socket-timeout", "30", "--retries", "0", "--fragment-retries", "0",
            "--abort-on-unavailable-fragments", "--concurrent-fragments", "1",
            "--cookies", str(cookie_file), "--hls-use-mpegts", "--remux-video", "mp4",
            "--merge-output-format", "mp4", "--max-filesize", str(max_bytes // 2),
            "-f", f"bv*[height<={quality}]+ba/b[height<={quality}]/b",
            "-o", str(work / "source.%(ext)s")]
    for key, value in stream.headers.items():
        args += ["--add-header", f"{key}:{value}"]
    args += ["--", stream.url]
    try:
        await run_process(args, work, timeout=timeout, max_bytes=max_bytes,
                          progress_file=progress_file, on_progress=on_progress)
    except MediaProcessError as exc:
        if rate_report.exists():
            data = json.loads(rate_report.read_text())
            if data.get("status") == 429:
                raise RateLimitError(data.get("retry_after")) from exc
        if "429" in exc.summary or "too many requests" in exc.summary.lower():
            raise RateLimitError() from exc
        raise
    finally:
        cookie_file.unlink(missing_ok=True)
    source = work / "source.mp4"
    if not source.exists() or not source.stat().st_size:
        raise MediaError("Downloader did not produce source.mp4 (possibly over the disk-size limit).")
    original_info = await probe(source)
    # No intermediate video encode: DAR correction, padding and burn-in share one pass.
    caption_mode = "burn" if language == "dub" else subtitle_mode
    if caption_mode not in {"burn", "mux", "none"}:
        raise ValueError("SUBTITLE_MODE must be burn, mux or none.")
    note = None
    subtitle = None
    if caption_mode != "none":
        track = choose_caption(stream.tracks)
        if track is None:
            note = "No advertised English caption track; existing hardcoded subtitles, if any, are unchanged."
        else:
            subtitle = work / "subtitles.vtt"
            subtitle.write_bytes(await stream.caption_bytes(track))
    video = next(item for item in original_info["streams"] if item.get("codec_type") == "video")
    filters = video_filter(video, quality, bool(subtitle and caption_mode == "burn"))
    result = work / "episode.mp4"
    if on_phase: on_phase("Padding + captions" if subtitle and caption_mode == "burn" else "Padding video")
    args = ["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "warning", "-y", "-i", str(source)]
    if subtitle and caption_mode == "mux": args += ["-i", str(subtitle)]
    args += ["-map", "0:v:0", "-map", "0:a:0?", "-vf", filters,
             "-c:v", "libx264", "-preset", encoder_preset, "-crf", "23", "-pix_fmt", "yuv420p",
             "-c:a", "aac", "-b:a", "128k"]
    if upload_limit:
        bitrate = int(upload_limit * 8 / float(original_info['format']['duration']) * .88 - 128000)
        if bitrate < 180000:
            raise UploadTooLarge('Whole episode cannot fit the configured cap at usable quality; no splitting performed.')
        args += ["-maxrate", str(bitrate), "-bufsize", str(bitrate*2)]
    if subtitle and caption_mode == "mux":
        args += ["-map", "1:0", "-c:s", "mov_text", "-metadata:s:s:0", "language=eng", "-disposition:s:0", "default"]
    args += ["-movflags", "+faststart", str(result)]
    # Burn failure is a real failure. Never silently replace opaque captions with soft subtitles.
    await run_process(args, work, timeout=timeout, max_bytes=max_bytes)
    result_info = await probe(result)
    if "mp4" not in result_info['format'].get('format_name','').split(','):
        raise MediaError('Final video is not a real MP4 container.')
    if abs(float(result_info['format']['duration'])-float(original_info['format']['duration'])) > 3:
        raise MediaError('MP4 duration changed unexpectedly; refusing a potentially incomplete episode.')
    source.unlink()
    (work/'ready.json').write_text(json.dumps({'processing_version': PROCESSING_VERSION,
        'file':result.name, 'language':language, 'quality':quality, 'subtitle_mode':subtitle_mode,
        'encoder_preset':encoder_preset, 'note':note}))
    return result,note


PROCESSING_VERSION = 2


def video_filter(video, quality, burn=False):
    """Square-pixel, even-sized 16:9 canvas; fit the complete source display aspect."""
    from fractions import Fraction
    width,height=int(video['width']),int(video['height'])
    try: sar=float(Fraction(str(video.get('sample_aspect_ratio','1:1')).replace(':','/')))
    except (ValueError,ZeroDivisionError): sar=1.0
    if sar<=0: sar=1.0
    dar=width*sar/height
    rotation=video.get('tags',{}).get('rotate',0)
    for side in video.get('side_data_list',[]):
        if 'rotation' in side: rotation=side['rotation']
    if abs(round(float(rotation))) % 180 == 90:
        width,height=height,width;dar=1/dar
    canvas_h=max(18,int(min(quality,height))//18*18)
    canvas_w=canvas_h//9*16
    fit_h=min(canvas_h,canvas_w/dar)
    fit_w=fit_h*dar
    scaled_w=max(2,min(canvas_w,round(fit_w/2)*2))
    scaled_h=max(2,min(canvas_h,round(fit_h/2)*2))
    result=f"scale={scaled_w}:{scaled_h},setsar=1,pad={canvas_w}:{canvas_h}:(ow-iw)/2:(oh-ih)/2:color=black"
    if burn:
        result += ",subtitles=subtitles.vtt:force_style='FontName=DejaVu Sans,FontSize=22,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BackColour=&H00000000,BorderStyle=3,Outline=3,Shadow=0,MarginV=20,Alignment=2'"
    return result


async def cached_video(work: Path, language: str, quality: int, subtitle_mode: str,
                       subtitle_fallback=False, encoder_preset='ultrafast'):
    marker=work/'ready.json'
    if not marker.exists(): return None
    try:
        data=json.loads(marker.read_text())
        if data.get('processing_version') != PROCESSING_VERSION: return None
        if (data['language'],data['quality'],data['subtitle_mode'],data.get('encoder_preset')) != (language,quality,subtitle_mode,encoder_preset):
            return None
        source=work/data['file']
        if source.parent.resolve()!=work.resolve(): return None
        await probe(source)
        return source,data.get('note')
    except (ValueError,KeyError,OSError,MediaError):
        return None


async def fit_whole_video(source: Path, limit: int, *, timeout=3600, max_bytes=8*1024**3):
    if source.stat().st_size <= limit:
        return source
    duration = float((await probe(source))['format']['duration'])
    for attempt in range(2):
        bitrate = int((limit * 8 / duration * (0.88 if attempt == 0 else 0.70)) - 128000)
        if bitrate < 180000:
            raise UploadTooLarge('Whole episode is too long to fit this cap at usable quality; no splitting performed.')
        result = source.parent/('fitted-1.mp4' if source.name != 'fitted-1.mp4' else 'fitted-2.mp4')
        await run_process(['ffmpeg','-nostdin','-hide_banner','-loglevel','warning','-y','-i',str(source),
            '-map','0:v:0','-map','0:a:0?','-map','0:s?', '-c:v','libx264','-preset','veryfast',
            '-b:v',str(bitrate),'-maxrate',str(bitrate),'-bufsize',str(bitrate*2),'-pix_fmt','yuv420p',
            '-c:a','aac','-b:a','128k','-c:s','mov_text','-movflags','+faststart',str(result)],
            source.parent,timeout=timeout,max_bytes=max_bytes)
        actual = await probe(result)
        if abs(float(actual['format']['duration'])-duration) > 3:
            raise MediaError('Compressed-video duration mismatch. No truncated file will be uploaded.')
        if result.stat().st_size <= limit: return result
    raise UploadTooLarge('Whole episode is still above the configured cap after compression. No splitting performed.')


class UploadTooLarge(MediaError):
    pass


def check_upload_size(source: Path, limit: int) -> Path:
    """Require one whole MP4; never split, truncate or silently compress it."""
    if limit < 1:
        raise ValueError("Upload limit must be positive.")
    size = source.stat().st_size
    if size > limit:
        raise UploadTooLarge(
            f"Whole episode is {size / 1_000_000:.1f} MB; configured cap is "
            f"{limit / 1_000_000:.1f} MB. No file uploaded and no splitting performed.")
    return source
