# ANIMAX V2

Whole MP4 episodes · black 16:9 padding · opaque burned captions · resume and local search.

Uses **discord.py-self 2.1.0**, as requested. Episodes are downloaded and uploaded sequentially, one whole video per message. No splitting or truncating. Default configured cap: **1,000 MB (1,000,000,000 bytes)**; Discord still enforces your account's actual entitlement.

> Discord prohibits automated normal user accounts and may terminate the account. An official bot account is the compliant alternative. See https://support.discord.com/hc/en-us/articles/115002192352-Automated-User-Accounts-Self-Bots . Only download/repost content you are authorized to distribute. Keep your token private.
>
> External providers, caption availability, permissions and rate limits prevent any honest 100% success guarantee. Failed and uncertain uploads are not silently marked successful.

## Upgrade `/Holy/animaxv1` without losing history

Extract into a **separate directory**, stop the current process, then apply the code-only update:

```bash
sudo systemctl stop animax
unzip animax-v2.zip
sudo python3 animax-v2/apply_update.py --target /Holy/animaxv1
sudo systemctl start animax
```

The updater backs up replaced code in `.release-backups/` and preserves `.env`, real `anime.json`, legacy `state.json`, cooldowns, title overrides, downloads, logs, `.venv` and browser binaries. It keeps file ownership/modes. The existing service path does not change. New Python dependencies are installed automatically by the bootstrap at startup.

For detached mode, replace the service stop/start with:

```bash
python3 /Holy/animaxv1/service.py stop-detached
# Apply update here, while stopped.
python3 /Holy/animaxv1/service.py detach
```

Do not run the extracted new folder and existing installation simultaneously. Do not replace real history with `anime.example.json`. This ZIP contains neither live settings/history nor test files.

**Upgrade behavior:** earlier verified outputs remain on disk but V2 will not reuse pre-V2 encoded videos: those files have not passed the new padding/caption processing rules. Already uploaded episodes remain completed and are skipped unless `force` is deliberately requested. Existing `SUBTITLE_FALLBACK` is ignored: V2 never silently replaces burned captions with a soft track. Legacy `PREPARE_TIMEOUT` is accepted but unused by the new single-pass preparation pipeline.

New settings work without adding them to an existing `.env`:

```dotenv
ENCODER_PRESET=ultrafast
DUB_FALLBACK=true
```

## New installation — Ubuntu / Debian

Python **3.11+ recommended**. Source syntax remains compatible with 3.10, but current downloader support for that interpreter is deprecated.

```bash
unzip animax-v2.zip
cd animax-v2
bash install.sh
```

`install.sh` installs FFmpeg/ffprobe, DejaVu fonts and Python/Chromium requirements. Edit `.env` locally:

```dotenv
DISCORD_TOKEN=your_account_token
CHANNEL_ID=0
UPLOAD_LIMIT_MB=1000
```

Choose **one** execution mode:

```bash
# Foreground
.venv/bin/python bot.py

# Recommended for SSH-safe execution and restart at boot
sudo python3 service.py install

# Alternative without systemd; survives SSH logout, not a host reboot
python3 service.py detach
```

Omit `sudo` when already root. Prefer a dedicated non-root project owner when practical. The systemd service runs as the project directory's owner; that account must be able to read `.env` and write the project. An instance lock prevents two workers in the same installation.

Management:

```bash
sudo python3 service.py status
sudo python3 service.py logs
sudo python3 service.py restart
sudo python3 service.py stop
python3 service.py status-detached
python3 service.py stop-detached
```

If migrating to a different directory from an older project, stop it first and run `python3 migrate.py --from /path/to/old/project` in the new directory. This preserves settings/history and refuses to overwrite non-empty destination data unless explicitly requested with `--replace` (backed up). Legacy single-message records are imported; legacy split-video records do not count as complete whole-episode deliveries.

## Commands

`.help` displays:

**Commands**
```text
download, status, cancel, resume, history, search, getlist, help
```
do .help <name> to see specific syntax.

| Command | Usage |
|---|---|
| Download | `.download MAL_ID dub\|sub START END [resume\|force]` |
| Status | `.status` |
| Cancel | `.cancel` |
| Resume | `.resume` or `.retry` |
| History | `.history MAL_ID` |
| Search uploaded episodes | `.search QUERY` |
| Export journal | `.getlist` |
| Specific help | `.help download` (or another command name) |

Examples:

```text
.download 21 dub 1 10
.download 21 sub 11 20
.search One piece episode 1
.search eisode 1 onepimse
.getlist
```

Ranges are **inclusive**. Only commands authored by the logged-in account are processed. `. download` is also accepted. Resume skips already uploaded episodes and can repair pending download-link edits. `force` deliberately resends and can create duplicates: check the destination before using it, especially after an uncertain send.

### Progress and deletion

Each episode needing work has its own one-line status in the **command channel**:

```text
**One Piece** | `E1` | Downloading | 1%
```

The title renders bold. A percentage reflects download progress (byte totals or fragment estimates); preparation and upload stages use `—`, not a fictional upload percentage. A confirmed, journaled upload shows `Uploaded | 100%`.

- With **nonzero `CHANNEL_ID`**, automatic episode statuses are **retained**, including the final status. Video attachments go to that configured destination.
- With `CHANNEL_ID=0`, successful automatic statuses are deleted only after Discord confirms the video message and its accepted ID is committed to `anime.json`.
- Failed/cancelled/uncertain statuses remain. Explicit `.status` responses are not automatically deleted.
- The **accepted `.download` command trigger is still deleted**, independently of the retained status. Set `DELETE_DOWNLOAD_TRIGGER=false` to keep it too. Invalid/rejected triggers are not deleted.
- Cleanup failure never turns an accepted upload into a failed video. Deferred cleanup/finalization can be retried on resume.

### Video captions, replies and direct downloads

After Discord returns the attachment URL, the video caption is edited to:

```text
**One Piece** | `E1` | [download](Discord attachment CDN URL)
```

The accepted message ID is **committed before this edit**. A failed edit leaves the video safely recorded and marks its caption pending; `.resume` attempts caption repair without resending the video. Before that edit, the caption contains the title and episode only.

E2 replies to the stored E1 upload in the same destination/account/anime. If E1 is absent, the nearest earlier uploaded episode is used; if none exists, the message is unthreaded. For equal episode numbers, the requested-language chain is preferred. Reply mentions are disabled and missing references use Discord's `fail_if_not_exists=false` behavior. Replies reference episode **video messages**, not progress messages.

**CDN links expire:** the hyperlink uses the actual signed attachment URL returned by Discord, not an invented permanent link. Search links point to the more durable Discord message permalink. Channel permissions/deleted messages still affect access. A successful caption link is not continuously refreshed after expiry; open the original attachment from its Discord message for a fresh download.

### Search and getlist

Search is fuzzy and order-independent over **uploaded records in this account's local `anime.json`**, not the provider catalog or every message in Discord. It recognizes episode markers and common misspellings, filters an explicit episode number and returns up to five best matches:

```text
One Piece `E1` : [Click here](uploaded-message permalink)
```

A bare numeric token alongside a title is treated as an episode hint; use an explicit `episode N` for numeric anime titles. Old records without permalinks use the destination's resolved guild/DM information; inaccessible legacy destinations are skipped. Search does not verify that every historical message still exists.

`.getlist` sends **only an `anime.json` attachment**—no acknowledgement, caption, embed or accompanying text. The export contains account/channel/message metadata and may include signed attachment URLs, so share it carefully. It contains no Discord token.

## Video frame and captions

### Full-frame 16:9 padding

The source display aspect ratio is preserved, including non-square source pixels. The complete frame is scaled down as necessary and centered on an even-sized **16:9 black canvas** with square pixels:

- A 4:3 episode receives baked-in **black side bars**, like the supplied screenshot.
- A 16:9 episode fills the canvas; wider cinema material receives top/bottom padding.
- No crop filter and no stretching to fill the canvas. Pixel dimensions use necessary integer/even rounding.
- No unnecessary vertical upscaling. Output height is capped by `QUALITY` and source height, rounded to an even 16:9 canvas.
- Pixels already cropped out by the upstream provider cannot be restored.

### Dub captions: always visible and opaque

For **dub** videos, available advertised English WebVTT tracks are burned into the picture with white text and a **100% opaque black background box**. Dub captions are burned even if an older `.env` has `SUBTITLE_MODE=mux` or `none`. They are not toggleable.

The provider must actually supply an English track. Missing tracks are not manufactured or automatically transcribed; the status/video caption says `Captions unavailable`. Existing hardcoded subtitles, if present, remain unchanged. A provider's English translation track may not match the dub script or include sound-effect CC. V2 does not claim to generate accurate missing dub closed captions.

For **sub** videos (including a dub→sub fallback), `SUBTITLE_MODE=burn` is the default and uses the same opaque style. Advanced `mux` embeds selectable subtitles, which Discord may not display; `none` omits external tracks. Padding still applies in both modes. A requested burn failure is a real error—never a silent soft-subtitle substitution.

### Faster preparation

Scaling, aspect correction, black padding and burned captions share **one H.264 encode pass**, rather than separate padding/burn encodes. Audio becomes AAC; the output is a fast-start MP4. `ENCODER_PRESET=ultrafast` prioritizes speed; `superfast`/`veryfast` can reduce file size at higher CPU cost. Actual processing time depends on CPU, source resolution, runtime and disk speed; no fixed speedup is promised.

With `AUTO_COMPRESS=true`, the main encode receives a cap-derived bitrate ceiling. If its final file still exceeds the cap, bounded whole-video recompression can require an additional pass. Duration/container/size are checked before upload. A video that cannot fit is rejected, never split or truncated.

## Automatic dub → sub fallback

`DUB_FALLBACK=true` checks each requested episode independently. It switches to sub only on positive source-availability evidence: a provider 404/410, its explicit 404/410 error page (sometimes returned as HTTP 200), an empty unencrypted source list, or an explicit missing-source response.

Timeouts, generic player failures, rate limits, 403/5xx responses, caption-download failures and Discord upload errors do **not** authorize a language change. If availability cannot be established, the job retries/stops normally instead of guessing.

A fallback is labeled `SUB (dub unavailable)` in status/video captions. Filenames and journal fields reflect the **actual language**, while the requested `dub` job remains unchanged; the next episode tries dub again. A completed fallback satisfies that requested episode on resume. Search labels fallback results. Set `DUB_FALLBACK=false` if you prefer failure rather than switching audio.

## Reliability, limits and privacy

- Sequential native HLS download with one fragment worker; no network-FFmpeg bypass, proxy rotation or skipping fragments.
- Starts at 0.25-second request spacing; HTTP 429 persists a cooldown, honors Retry-After and increases pacing. No episode hopping while rate-limited. Do not delete cooldown files or run multiple downloaders to evade a limit.
- Public `discord.py-self` cloud-attachment API is preferred. Multipart is used only when the capability is absent or explicitly selected, not blindly after rejection/uncertain confirmation.
- Confirmation timeout/cancellation or a failed accepted-ID journal commit can leave an uncertain send. Such jobs require review and are not blindly auto-resent. Exactly-once delivery across a remote API and local disk cannot be guaranteed.
- `AUTO_RESUME=true` resumes queued/running/interrupted jobs for the same account. A safely cancelled or needs-review job is not an automatic restart candidate.
- Journal writes are atomic with `anime.json.bak`. A failed forced resend does not erase earlier accepted messages. Requested and actual languages, fallback reasons, progress references, accepted IDs, permalinks, reply IDs and caption-edit state are recorded.
- Verified V2 completed videos can be reused after an upload failure. Safe partial native downloads can resume when the source fingerprint still matches.
- Successful working directories are removed unless `KEEP_DOWNLOADS=true`. Failed work is retained. Monitor disk usage; delete unwanted cache directories only while stopped.
- Detailed media logs may contain signed source URLs. Redact logs before sharing. Tokens are never part of release files or the journal.

## Settings

See `.env.example`; restart after changing settings.

| Setting | Default | Purpose |
|---|---:|---|
| `CHANNEL_ID` | `0` | Destination; nonzero also retains episode statuses |
| `UPLOAD_LIMIT_MB` | `1000` | Decimal MB cap; account entitlement still authoritative |
| `AUTO_COMPRESS` | `true` | Bitrate cap and bounded whole-video compression |
| `QUALITY` | `720` | Preferred source height / output canvas height ceiling |
| `ENCODER_PRESET` | `ultrafast` | x264 CPU-speed/size trade-off |
| `SUBTITLE_MODE` | `burn` | Sub videos: `burn`, `mux`, `none`; dub always burns available English tracks |
| `DUB_FALLBACK` | `true` | Permit availability-confirmed dub→sub fallback |
| `UPLOAD_MODE` | `auto` | `auto`, `cloud`, `multipart` |
| `UPLOAD_TIMEOUT` | `1800` | Upload plus confirmation deadline, seconds |
| `OPERATION_TIMEOUT` | `3600` | Per download/encode deadline, seconds |
| `RESOLVE_TIMEOUT` | `60` | Source-resolution deadline, seconds |
| `REQUEST_INTERVAL` | `0.25` | Initial native request spacing, seconds |
| `RATE_LIMIT_COOLDOWN` | `300` | Initial 429 cooldown; longer Retry-After wins |
| `RATE_LIMIT_RETRIES` | `2` | Same-episode retries after cooldown |
| `EPISODE_ATTEMPTS` | `3` | Bounded non-429 resolution/download attempts |
| `MAX_CONSECUTIVE_FAILURES` | `3` | Stop after consecutive episode failures |
| `STATUS_INTERVAL` | `8` | Progress-edit interval, seconds |
| `UPLOAD_DELAY` | `2` | Episode-send spacing; channel slowmode can increase it |
| `DELETE_DOWNLOAD_TRIGGER` | `true` | Delete only an accepted download command trigger |
| `AUTO_RESUME` | `true` | Resume interrupted jobs at startup |
| `KEEP_DOWNLOADS` | `false` | Keep successfully delivered files |
| `MAX_TEMP_GIB` | `8` | Per-episode temporary storage budget |
| `MAX_EPISODES` | `1000` | Maximum inclusive range |
| `HEADLESS` | `true` | Headless Chromium |

`SUBTITLE_FALLBACK`, `PREPARE_TIMEOUT` and the much older `CDN_REQUEST_INTERVAL` no longer control V2 behavior. Existing values are harmless; keep `REQUEST_INTERVAL` for current pacing.

## Dependencies, diagnostics and validation

`python3 bot.py` creates/uses a private `.venv`, installs missing Python packages, repairs conflicting Discord libraries in that environment, and installs missing Chromium binaries. OS libraries/FFmpeg/fonts require `install.sh` or your distribution's package manager; Python cannot supply OS permissions or a missing base interpreter.

```bash
python3 bot.py --setup
python3 bot.py --repair
.venv/bin/python doctor.py
# Only while no CDN cooldown is active:
.venv/bin/python doctor.py --source 21 dub 1
```

The source doctor checks browser/manifest access, not a full episode upload and not automatic fallback. Reports are written to `logs/doctor-report.json`.

For problems:

```bash
tail -n 80 /Holy/animaxv1/logs/bot.log
cat /Holy/animaxv1/logs/upload-21-dub-1.json
```

Upload reports separate cloud upload, final posting, accepted message ID, HTTP/code errors and uncertain outcome. Media logs record process START/END, exit code and elapsed time. An FFmpeg warning with exit 0 does not by itself prove a failure. If no new upload report exists, inspect the previous preparation stage and compare timestamps.

The terminal is compact and colored on a TTY; redirected/service logs use milestone lines without cursor animation. Discord messages stay concise; detailed errors remain in logs.

**Validation:** 48 automated checks passed on Python 3.13/Linux, including real synthetic HLS download, actual FFmpeg conversion/compression, square/anamorphic/wide frame preservation, black padding and opaque-caption pixel checks, single-pass dub burn, fuzzy search, attachment-only export, fallback classification, reply chains, retained statuses, caption repair without resend, uncertain-send safety, updater data preservation and prior regression checks. Python 3.10 syntax and installer shell syntax are checked separately; that is not a full 3.10 runtime test.

**Not tested with a real Discord account:** no actual V2 login/upload, 1 GB entitlement verification, host reboot, or installed systemd service run. Discord lifecycle tests use mocks; media tests use real FFmpeg. A live provider missing-source page was inspected, but a full live V2 episode download was not performed. Test sources/reports, generated media, caches, browsers, credentials and logs are excluded from this ZIP.
